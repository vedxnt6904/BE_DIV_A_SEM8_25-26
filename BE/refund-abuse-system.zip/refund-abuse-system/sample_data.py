import sqlite3
from datetime import datetime, timedelta
import random

def insert_sample_data():
    """Insert sample data for testing"""
    conn = sqlite3.connect('refund_abuse.db')
    cursor = conn.cursor()
    
    # Insert sample customers
    customers = [
        ('normal.customer@example.com', 'John Normal', '123-456-7890'),
        ('suspicious.customer@example.com', 'Jane Suspicious', '123-456-7891'),
        ('frequent.returner@example.com', 'Bob Frequent', '123-456-7892'),
        ('high.value@example.com', 'Alice Highvalue', '123-456-7893'),
        ('new.customer@example.com', 'Charlie New', '123-456-7894')
    ]
    
    cursor.executemany(
        "INSERT INTO customers (email, name, phone) VALUES (?, ?, ?)",
        customers
    )
    
    # Get customer IDs
    cursor.execute("SELECT id FROM customers ORDER BY id")
    customer_ids = [row[0] for row in cursor.fetchall()]
    
    # Insert sample orders
    orders = []
    for customer_id in customer_ids:
        # Create 5-10 orders per customer
        for order_num in range(random.randint(5, 10)):
            order_date = datetime.now() - timedelta(days=random.randint(1, 180))
            total_amount = round(random.uniform(50, 500), 2)
            orders.append((
                customer_id,
                order_date.strftime('%Y-%m-%d %H:%M:%S'),
                total_amount,
                'completed'
            ))
    
    cursor.executemany(
        "INSERT INTO orders (customer_id, order_date, total_amount, status) VALUES (?, ?, ?, ?)",
        orders
    )
    
    # Get order IDs
    cursor.execute("SELECT id, customer_id, total_amount FROM orders")
    orders_data = cursor.fetchall()
    
    # Insert sample returns - creating suspicious patterns for specific customers
    returns = []
    suspicious_customer_id = customer_ids[1]  # Jane Suspicious
    frequent_customer_id = customer_ids[2]    # Bob Frequent
    
    for order_id, customer_id, total_amount in orders_data:
        # Create suspicious pattern for Jane Suspicious
        if customer_id == suspicious_customer_id and random.random() < 0.8:  # 80% return rate
            return_date = datetime.now() - timedelta(days=random.randint(1, 30))
            refund_amount = total_amount * 0.8  # Partial refund
            returns.append((
                order_id,
                customer_id,
                return_date.strftime('%Y-%m-%d %H:%M:%S'),
                'Changed mind',
                refund_amount,
                'approved',
                '1 item'
            ))
        
        # Create frequent returns for Bob Frequent
        elif customer_id == frequent_customer_id and random.random() < 0.6:  # 60% return rate
            return_date = datetime.now() - timedelta(days=random.randint(1, 60))
            returns.append((
                order_id,
                customer_id,
                return_date.strftime('%Y-%m-%d %H:%M:%S'),
                'Not as described',
                total_amount,
                'approved',
                '1 item'
            ))
        
        # Normal return rate for others (10-20%)
        elif random.random() < 0.15:
            return_date = datetime.now() - timedelta(days=random.randint(1, 90))
            returns.append((
                order_id,
                customer_id,
                return_date.strftime('%Y-%m-%d %H:%M:%S'),
                random.choice(['Wrong size', 'Defective', 'Changed mind']),
                total_amount * random.uniform(0.5, 1.0),
                'approved',
                '1 item'
            ))
    
    cursor.executemany('''
    INSERT INTO returns (order_id, customer_id, return_date, return_reason, refund_amount, return_status, items_returned)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', returns)
    
    conn.commit()
    conn.close()
    print("Sample data inserted successfully!")

if __name__ == "__main__":
    insert_sample_data()