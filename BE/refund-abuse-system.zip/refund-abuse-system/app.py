# from flask import Flask, render_template, request, jsonify
# import sqlite3
# import pandas as pd
# from detection_system import RefundAbuseDetector
# import csv
# import io
# from datetime import datetime

# app = Flask(__name__)

# @app.route('/')
# def dashboard():
#     conn = sqlite3.connect('refund_abuse.db')
#     flagged_customers = pd.read_sql_query("""
#     SELECT c.id, c.email, c.name, c.risk_score, af.severity, af.flag_reason, af.created_at
#     FROM customers c
#     JOIN abuse_flags af ON c.id = af.customer_id
#     WHERE af.is_active = TRUE
#     ORDER BY c.risk_score DESC
#     """, conn)
    
#     stats = pd.read_sql_query("""
#     SELECT 
#         COUNT(*) as total_customers,
#         SUM(CASE WHEN is_flagged THEN 1 ELSE 0 END) as flagged_customers,
#         AVG(risk_score) as avg_risk_score
#     FROM customers
#     """, conn)
#     conn.close()
    
#     return render_template('dashboard.html', 
#                          customers=flagged_customers.to_dict('records'),
#                          stats=stats.to_dict('records')[0])

# @app.route('/scan')
# def scan_customers():
#     detector = RefundAbuseDetector('refund_abuse.db')
#     flagged = detector.scan_for_abuse(days=90)
#     return jsonify({
#         'message': f'Scan completed. Found {len(flagged)} suspicious customers.',
#         'flagged_customers': flagged
#     })


# if __name__ == '__main__':
#     app.run(debug=True, host='0.0.0.0', port=5000)



# from flask import Flask, render_template, request, jsonify, Response  # CHANGED: Added Response
# import sqlite3
# import pandas as pd
# from detection_system import RefundAbuseDetector
# import csv
# import io
# from datetime import datetime

# app = Flask(__name__)

# # ===== EXISTING ROUTES (KEEP THESE) =====
# @app.route('/')
# def dashboard():
#     conn = sqlite3.connect('refund_abuse.db')
#     flagged_customers = pd.read_sql_query("""
#     SELECT c.id, c.email, c.name, c.risk_score, af.severity, af.flag_reason, af.created_at
#     FROM customers c
#     JOIN abuse_flags af ON c.id = af.customer_id
#     WHERE af.is_active = TRUE
#     ORDER BY c.risk_score DESC
#     """, conn)
    
#     stats = pd.read_sql_query("""
#     SELECT 
#         COUNT(*) as total_customers,
#         SUM(CASE WHEN is_flagged THEN 1 ELSE 0 END) as flagged_customers,
#         AVG(risk_score) as avg_risk_score
#     FROM customers
#     """, conn)
#     conn.close()
    
#     return render_template('dashboard.html', 
#                          customers=flagged_customers.to_dict('records'),
#                          stats=stats.to_dict('records')[0])

# @app.route('/scan')
# def scan_customers():
#     detector = RefundAbuseDetector('refund_abuse.db')
#     flagged = detector.scan_for_abuse(days=90)
#     return jsonify({
#         'message': f'Scan completed. Found {len(flagged)} suspicious customers.',
#         'flagged_customers': flagged
#     })

# # ===== NEW EXPORT ROUTES (ADD THESE AFTER THE EXISTING ROUTES) =====

# @app.route('/export/flagged_customers')
# def export_flagged_customers():
#     """Export flagged customers to CSV"""
#     try:
#         conn = sqlite3.connect('refund_abuse.db')
        
#         # Get flagged customers data
#         flagged_customers = pd.read_sql_query("""
#         SELECT 
#             c.id as "Customer ID",
#             c.name as "Customer Name",
#             c.email as "Email",
#             c.phone as "Phone",
#             c.risk_score as "Risk Score",
#             af.severity as "Severity",
#             af.flag_reason as "Flag Reasons",
#             af.created_at as "Flag Date",
#             c.created_at as "Customer Since"
#         FROM customers c
#         JOIN abuse_flags af ON c.id = af.customer_id
#         WHERE af.is_active = TRUE
#         ORDER BY c.risk_score DESC
#         """, conn)
        
#         conn.close()
        
#         # Create CSV in memory
#         output = io.StringIO()
#         flagged_customers.to_csv(output, index=False)
#         output.seek(0)
        
#         # Create filename with timestamp
#         timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#         filename = f"flagged_customers_{timestamp}.csv"
        
#         return Response(
#             output.getvalue(),
#             mimetype="text/csv",
#             headers={
#                 "Content-Disposition": f"attachment; filename={filename}",
#                 "Content-type": "text/csv"
#             }
#         )
    
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# @app.route('/export/customer_details/<int:customer_id>')
# def export_customer_details(customer_id):
#     """Export detailed customer history to CSV"""
#     try:
#         conn = sqlite3.connect('refund_abuse.db')
        
#         # Get customer basic info
#         customer_info = pd.read_sql_query("""
#         SELECT 
#             name as "Customer Name",
#             email as "Email",
#             phone as "Phone",
#             risk_score as "Risk Score",
#             created_at as "Customer Since"
#         FROM customers 
#         WHERE id = ?
#         """, conn, params=[customer_id])
        
#         # Get customer order and return history
#         customer_history = pd.read_sql_query("""
#         SELECT 
#             o.id as "Order ID",
#             o.order_date as "Order Date",
#             o.total_amount as "Order Amount",
#             r.return_date as "Return Date",
#             r.return_reason as "Return Reason",
#             r.refund_amount as "Refund Amount",
#             r.return_status as "Return Status",
#             CASE WHEN r.id IS NOT NULL THEN 'Yes' ELSE 'No' END as "Item Returned"
#         FROM orders o
#         LEFT JOIN returns r ON o.id = r.order_id
#         WHERE o.customer_id = ?
#         ORDER BY o.order_date DESC
#         """, conn, params=[customer_id])
        
#         conn.close()
        
#         # Create CSV with multiple sections
#         output = io.StringIO()
        
#         # Write customer info section
#         output.write("CUSTOMER INFORMATION\n")
#         customer_info.to_csv(output, index=False)
#         output.write("\n\nORDER AND RETURN HISTORY\n")
#         customer_history.to_csv(output, index=False)
        
#         output.seek(0)
        
#         timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#         filename = f"customer_{customer_id}_details_{timestamp}.csv"
        
#         return Response(
#             output.getvalue(),
#             mimetype="text/csv",
#             headers={
#                 "Content-Disposition": f"attachment; filename={filename}",
#                 "Content-type": "text/csv"
#             }
#         )
    
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# @app.route('/export/all_data')
# def export_all_data():
#     """Export comprehensive report with all data"""
#     try:
#         conn = sqlite3.connect('refund_abuse.db')
        
#         # 1. System Summary
#         summary = pd.read_sql_query("""
#         SELECT 
#             COUNT(*) as "Total Customers",
#             SUM(CASE WHEN is_flagged THEN 1 ELSE 0 END) as "Flagged Customers",
#             AVG(risk_score) as "Average Risk Score",
#             (SELECT COUNT(*) FROM returns WHERE return_date >= datetime('now', '-30 days')) as "Returns Last 30 Days",
#             (SELECT AVG(refund_amount) FROM returns) as "Average Refund Amount"
#         FROM customers
#         """, conn)
        
#         # 2. All customers with risk scores
#         all_customers = pd.read_sql_query("""
#         SELECT 
#             id as "Customer ID",
#             name as "Name",
#             email as "Email",
#             risk_score as "Risk Score",
#             is_flagged as "Is Flagged",
#             created_at as "Customer Since"
#         FROM customers
#         ORDER BY risk_score DESC
#         """, conn)
        
#         # 3. Return statistics by customer
#         return_stats = pd.read_sql_query("""
#         SELECT 
#             c.id as "Customer ID",
#             c.name as "Customer Name",
#             COUNT(DISTINCT o.id) as "Total Orders",
#             COUNT(DISTINCT r.id) as "Total Returns",
#             ROUND(CAST(COUNT(DISTINCT r.id) AS FLOAT) / COUNT(DISTINCT o.id) * 100, 2) as "Return Rate %",
#             AVG(r.refund_amount) as "Average Refund Amount",
#             MAX(r.return_date) as "Last Return Date"
#         FROM customers c
#         LEFT JOIN orders o ON c.id = o.customer_id
#         LEFT JOIN returns r ON o.id = r.order_id
#         GROUP BY c.id, c.name
#         HAVING COUNT(DISTINCT r.id) > 0
#         ORDER BY "Return Rate %" DESC
#         """, conn)
        
#         conn.close()
        
#         # Create comprehensive CSV
#         output = io.StringIO()
        
#         output.write("REFUND ABUSE DETECTION SYSTEM - COMPREHENSIVE REPORT\n")
#         output.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
#         output.write("SYSTEM SUMMARY\n")
#         summary.to_csv(output, index=False)
#         output.write("\n\nALL CUSTOMERS RISK ASSESSMENT\n")
#         all_customers.to_csv(output, index=False)
#         output.write("\n\nRETURN STATISTICS BY CUSTOMER\n")
#         return_stats.to_csv(output, index=False)
        
#         output.seek(0)
        
#         timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#         filename = f"refund_abuse_comprehensive_report_{timestamp}.csv"
        
#         return Response(
#             output.getvalue(),
#             mimetype="text/csv",
#             headers={
#                 "Content-Disposition": f"attachment; filename={filename}",
#                 "Content-type": "text/csv"
#             }
#         )
    
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# # ===== KEEP THIS AT THE BOTTOM =====
# if __name__ == '__main__':
#     app.run(debug=True, host='0.0.0.0', port=5000)




# from flask import Flask, render_template, request, jsonify, Response
# import sqlite3
# import pandas as pd
# from detection_system import RefundAbuseDetector
# from detection_system_large import LargeRefundAbuseDetector  # ADD THIS IMPORT
# import csv
# import io
# from datetime import datetime
# # price comparision\
# from price_comparison.routes import price_bp



# app = Flask(__name__)

# app.secret_key = 'your-secret-key-here-make-it-random'  # ← ADD THIS LINE


# # price comparision     

# app.register_blueprint(price_bp, url_prefix='/price-comparison')  # Remove url_prefix

# # ===== DATABASE CONFIGURATION =====
# # Choose which database to use - change this to switch between small and large
# USE_LARGE_DATABASE = True  # Set to False to use small database, True for large database
# DB_PATH = 'large_refund_abuse.db' if USE_LARGE_DATABASE else 'refund_abuse.db'

# # ===== EXISTING ROUTES (UPDATED FOR LARGE DB) =====
# @app.route('/')
# def dashboard():
#     conn = sqlite3.connect(DB_PATH)
    
#     # For large databases, add pagination
#     page = request.args.get('page', 1, type=int)
#     per_page = 50 if USE_LARGE_DATABASE else 100  # Smaller pages for large DB
#     offset = (page - 1) * per_page
    
#     # Updated query with pagination for large database
#     if USE_LARGE_DATABASE:
#         flagged_customers = pd.read_sql_query(f"""
#         SELECT c.id, c.email, c.name, c.risk_score, af.severity, af.flag_reason, af.created_at
#         FROM customers c
#         JOIN abuse_flags af ON c.id = af.customer_id
#         WHERE af.is_active = TRUE
#         ORDER BY c.risk_score DESC
#         LIMIT {per_page} OFFSET {offset}
#         """, conn)
        
#         # Get total count for pagination
#         total_count = pd.read_sql_query("""
#         SELECT COUNT(*) as total FROM abuse_flags WHERE is_active = TRUE
#         """, conn).iloc[0]['total']
#         total_pages = (total_count + per_page - 1) // per_page
#     else:
#         flagged_customers = pd.read_sql_query("""
#         SELECT c.id, c.email, c.name, c.risk_score, af.severity, af.flag_reason, af.created_at
#         FROM customers c
#         JOIN abuse_flags af ON c.id = af.customer_id
#         WHERE af.is_active = TRUE
#         ORDER BY c.risk_score DESC
#         """, conn)
#         total_pages = 1
    
#     # Enhanced stats for both databases
#     stats = pd.read_sql_query(f"""
#     SELECT 
#         COUNT(*) as total_customers,
#         SUM(CASE WHEN is_flagged THEN 1 ELSE 0 END) as flagged_customers,
#         AVG(risk_score) as avg_risk_score,
#         (SELECT COUNT(*) FROM returns WHERE return_date >= datetime('now', '-30 days')) as recent_returns_30d,
#         (SELECT COUNT(*) FROM returns) as total_returns
#     FROM customers
#     """, conn)
    
#     conn.close()
    
#     return render_template('dashboard.html', 
#                          customers=flagged_customers.to_dict('records'),
#                          stats=stats.to_dict('records')[0],
#                          current_page=page,
#                          total_pages=total_pages,
#                          use_large_db=USE_LARGE_DATABASE)

# @app.route('/scan')
# def scan_customers():
#     # Use appropriate detector based on database size
#     if USE_LARGE_DATABASE:
#         detector = LargeRefundAbuseDetector(DB_PATH)
#     else:
#         detector = RefundAbuseDetector(DB_PATH)
    
#     flagged = detector.scan_for_abuse(days=90)
    
#     # For large databases, return only summary to avoid performance issues
#     if USE_LARGE_DATABASE:
#         return jsonify({
#             'message': f'Scan completed. Found {len(flagged)} suspicious customers.',
#             'flagged_count': len(flagged),
#             'top_customers': flagged[:10]  # Return only top 10
#         })
#     else:
#         return jsonify({
#             'message': f'Scan completed. Found {len(flagged)} suspicious customers.',
#             'flagged_customers': flagged
#         })

# # ===== NEW ROUTES FOR LARGE DATABASE FEATURES =====

# @app.route('/customer/<int:customer_id>')
# def customer_detail(customer_id):
#     """Get detailed customer information"""
#     try:
#         conn = sqlite3.connect(DB_PATH)
        
#         # Customer basic info
#         customer_info = pd.read_sql_query("""
#         SELECT 
#             c.id, c.name, c.email, c.phone, c.risk_score, c.created_at,
#             COUNT(DISTINCT o.id) as total_orders,
#             COUNT(DISTINCT r.id) as total_returns,
#             ROUND(CAST(COUNT(DISTINCT r.id) AS FLOAT) / COUNT(DISTINCT o.id) * 100, 2) as return_rate
#         FROM customers c
#         LEFT JOIN orders o ON c.id = o.customer_id
#         LEFT JOIN returns r ON o.id = r.order_id
#         WHERE c.id = ?
#         GROUP BY c.id, c.name, c.email, c.phone, c.risk_score, c.created_at
#         """, conn, params=[customer_id])
        
#         # Recent returns (last 90 days)
#         recent_returns = pd.read_sql_query("""
#         SELECT 
#             r.return_date, r.return_reason, r.refund_amount, r.return_status,
#             o.order_date, o.total_amount
#         FROM returns r
#         JOIN orders o ON r.order_id = o.id
#         WHERE r.customer_id = ? 
#         AND r.return_date >= datetime('now', '-90 days')
#         ORDER BY r.return_date DESC
#         LIMIT 20
#         """, conn, params=[customer_id])
        
#         conn.close()
        
#         return jsonify({
#             'customer_info': customer_info.to_dict('records')[0] if not customer_info.empty else {},
#             'recent_returns': recent_returns.to_dict('records')
#         })
    
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# @app.route('/stats')
# def get_detailed_stats():
#     """Get detailed statistics for large database"""
#     try:
#         conn = sqlite3.connect(DB_PATH)
        
#         # Comprehensive statistics
#         stats = pd.read_sql_query("""
#         WITH return_stats AS (
#             SELECT 
#                 COUNT(*) as total_returns,
#                 AVG(refund_amount) as avg_refund,
#                 COUNT(DISTINCT customer_id) as customers_with_returns,
#                 SUM(CASE WHEN return_date >= datetime('now', '-30 days') THEN 1 ELSE 0 END) as returns_30d
#             FROM returns
#         ),
#         customer_stats AS (
#             SELECT
#                 COUNT(*) as total_customers,
#                 AVG(risk_score) as avg_risk_score,
#                 SUM(CASE WHEN risk_score >= 70 THEN 1 ELSE 0 END) as high_risk_customers,
#                 SUM(CASE WHEN risk_score BETWEEN 40 AND 69 THEN 1 ELSE 0 END) as medium_risk_customers
#             FROM customers
#         )
#         SELECT * FROM return_stats, customer_stats
#         """, conn)
        
#         # Top 10 highest risk customers
#         top_risky = pd.read_sql_query("""
#         SELECT name, email, risk_score, severity, flag_reason
#         FROM customers c
#         JOIN abuse_flags af ON c.id = af.customer_id
#         WHERE af.is_active = TRUE
#         ORDER BY risk_score DESC
#         LIMIT 10
#         """, conn)
        
#         conn.close()
        
#         return jsonify({
#             'statistics': stats.to_dict('records')[0],
#             'top_risky_customers': top_risky.to_dict('records')
#         })
    
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# # ===== EXPORT ROUTES (UPDATED FOR LARGE DB) =====

# @app.route('/export/flagged_customers')
# def export_flagged_customers():
#     """Export flagged customers to CSV"""
#     try:
#         conn = sqlite3.connect(DB_PATH)
        
#         # For large databases, we might want to limit or batch exports
#         if USE_LARGE_DATABASE:
#             query = """
#             SELECT 
#                 c.id as "Customer ID",
#                 c.name as "Customer Name",
#                 c.email as "Email",
#                 c.phone as "Phone",
#                 c.risk_score as "Risk Score",
#                 af.severity as "Severity",
#                 af.flag_reason as "Flag Reasons",
#                 af.created_at as "Flag Date"
#             FROM customers c
#             JOIN abuse_flags af ON c.id = af.customer_id
#             WHERE af.is_active = TRUE
#             ORDER BY c.risk_score DESC
#             LIMIT 1000  -- Limit for large databases
#             """
#         else:
#             query = """
#             SELECT 
#                 c.id as "Customer ID",
#                 c.name as "Customer Name",
#                 c.email as "Email",
#                 c.phone as "Phone",
#                 c.risk_score as "Risk Score",
#                 af.severity as "Severity",
#                 af.flag_reason as "Flag Reasons",
#                 af.created_at as "Flag Date",
#                 c.created_at as "Customer Since"
#             FROM customers c
#             JOIN abuse_flags af ON c.id = af.customer_id
#             WHERE af.is_active = TRUE
#             ORDER BY c.risk_score DESC
#             """
        
#         flagged_customers = pd.read_sql_query(query, conn)
#         conn.close()
        
#         # Create CSV in memory
#         output = io.StringIO()
#         flagged_customers.to_csv(output, index=False)
#         output.seek(0)
        
#         # Create filename with timestamp and database type
#         db_type = "large" if USE_LARGE_DATABASE else "small"
#         timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#         filename = f"flagged_customers_{db_type}_{timestamp}.csv"
        
#         return Response(
#             output.getvalue(),
#             mimetype="text/csv",
#             headers={
#                 "Content-Disposition": f"attachment; filename={filename}",
#                 "Content-type": "text/csv"
#             }
#         )
    
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# @app.route('/export/customer_details/<int:customer_id>')
# def export_customer_details(customer_id):
#     """Export detailed customer history to CSV"""
#     try:
#         conn = sqlite3.connect(DB_PATH)
        
#         # Get customer basic info
#         customer_info = pd.read_sql_query("""
#         SELECT 
#             name as "Customer Name",
#             email as "Email",
#             phone as "Phone",
#             risk_score as "Risk Score",
#             created_at as "Customer Since"
#         FROM customers 
#         WHERE id = ?
#         """, conn, params=[customer_id])
        
#         # Get customer order and return history with limits for large DB
#         limit_clause = "LIMIT 500" if USE_LARGE_DATABASE else ""
        
#         customer_history = pd.read_sql_query(f"""
#         SELECT 
#             o.id as "Order ID",
#             o.order_date as "Order Date",
#             o.total_amount as "Order Amount",
#             r.return_date as "Return Date",
#             r.return_reason as "Return Reason",
#             r.refund_amount as "Refund Amount",
#             r.return_status as "Return Status",
#             CASE WHEN r.id IS NOT NULL THEN 'Yes' ELSE 'No' END as "Item Returned"
#         FROM orders o
#         LEFT JOIN returns r ON o.id = r.order_id
#         WHERE o.customer_id = ?
#         ORDER BY o.order_date DESC
#         {limit_clause}
#         """, conn, params=[customer_id])
        
#         conn.close()
        
#         # Create CSV with multiple sections
#         output = io.StringIO()
        
#         # Write customer info section
#         output.write("CUSTOMER INFORMATION\n")
#         customer_info.to_csv(output, index=False)
#         output.write("\n\nORDER AND RETURN HISTORY\n")
#         customer_history.to_csv(output, index=False)
        
#         output.seek(0)
        
#         timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#         filename = f"customer_{customer_id}_details_{timestamp}.csv"
        
#         return Response(
#             output.getvalue(),
#             mimetype="text/csv",
#             headers={
#                 "Content-Disposition": f"attachment; filename={filename}",
#                 "Content-type": "text/csv"
#             }
#         )
    
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# @app.route('/export/all_data')
# def export_all_data():
#     """Export comprehensive report with all data"""
#     try:
#         conn = sqlite3.connect(DB_PATH)
        
#         # For large databases, use more efficient queries
#         if USE_LARGE_DATABASE:
#             # 1. System Summary (optimized)
#             summary = pd.read_sql_query("""
#             SELECT 
#                 (SELECT COUNT(*) FROM customers) as "Total Customers",
#                 (SELECT COUNT(*) FROM abuse_flags WHERE is_active = TRUE) as "Flagged Customers",
#                 (SELECT AVG(risk_score) FROM customers) as "Average Risk Score",
#                 (SELECT COUNT(*) FROM returns WHERE return_date >= datetime('now', '-30 days')) as "Returns Last 30 Days",
#                 (SELECT AVG(refund_amount) FROM returns) as "Average Refund Amount",
#                 (SELECT COUNT(*) FROM returns) as "Total Returns"
#             """, conn)
            
#             # 2. Top 500 customers by risk score
#             all_customers = pd.read_sql_query("""
#             SELECT 
#                 id as "Customer ID",
#                 name as "Name",
#                 email as "Email",
#                 risk_score as "Risk Score",
#                 is_flagged as "Is Flagged",
#                 created_at as "Customer Since"
#             FROM customers
#             ORDER BY risk_score DESC
#             LIMIT 500
#             """, conn)
            
#             # 3. Return statistics by customer (top 500 by return rate)
#             return_stats = pd.read_sql_query("""
#             SELECT 
#                 c.id as "Customer ID",
#                 c.name as "Customer Name",
#                 COUNT(DISTINCT o.id) as "Total Orders",
#                 COUNT(DISTINCT r.id) as "Total Returns",
#                 ROUND(CAST(COUNT(DISTINCT r.id) AS FLOAT) / COUNT(DISTINCT o.id) * 100, 2) as "Return Rate %",
#                 AVG(r.refund_amount) as "Average Refund Amount",
#                 MAX(r.return_date) as "Last Return Date"
#             FROM customers c
#             LEFT JOIN orders o ON c.id = o.customer_id
#             LEFT JOIN returns r ON o.id = r.order_id
#             GROUP BY c.id, c.name
#             HAVING COUNT(DISTINCT r.id) > 0
#             ORDER BY "Return Rate %" DESC
#             LIMIT 500
#             """, conn)
#         else:
#             # Original queries for small database
#             summary = pd.read_sql_query("""
#             SELECT 
#                 COUNT(*) as "Total Customers",
#                 SUM(CASE WHEN is_flagged THEN 1 ELSE 0 END) as "Flagged Customers",
#                 AVG(risk_score) as "Average Risk Score",
#                 (SELECT COUNT(*) FROM returns WHERE return_date >= datetime('now', '-30 days')) as "Returns Last 30 Days",
#                 (SELECT AVG(refund_amount) FROM returns) as "Average Refund Amount"
#             FROM customers
#             """, conn)
            
#             all_customers = pd.read_sql_query("""
#             SELECT 
#                 id as "Customer ID",
#                 name as "Name",
#                 email as "Email",
#                 risk_score as "Risk Score",
#                 is_flagged as "Is Flagged",
#                 created_at as "Customer Since"
#             FROM customers
#             ORDER BY risk_score DESC
#             """, conn)
            
#             return_stats = pd.read_sql_query("""
#             SELECT 
#                 c.id as "Customer ID",
#                 c.name as "Customer Name",
#                 COUNT(DISTINCT o.id) as "Total Orders",
#                 COUNT(DISTINCT r.id) as "Total Returns",
#                 ROUND(CAST(COUNT(DISTINCT r.id) AS FLOAT) / COUNT(DISTINCT o.id) * 100, 2) as "Return Rate %",
#                 AVG(r.refund_amount) as "Average Refund Amount",
#                 MAX(r.return_date) as "Last Return Date"
#             FROM customers c
#             LEFT JOIN orders o ON c.id = o.customer_id
#             LEFT JOIN returns r ON o.id = r.order_id
#             GROUP BY c.id, c.name
#             HAVING COUNT(DISTINCT r.id) > 0
#             ORDER BY "Return Rate %" DESC
#             """, conn)
        
#         conn.close()
        
#         # Create comprehensive CSV
#         output = io.StringIO()
        
#         db_type = "LARGE" if USE_LARGE_DATABASE else "SMALL"
#         output.write(f"REFUND ABUSE DETECTION SYSTEM - COMPREHENSIVE REPORT ({db_type} DATABASE)\n")
#         output.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
#         output.write("SYSTEM SUMMARY\n")
#         summary.to_csv(output, index=False)
#         output.write("\n\nCUSTOMERS RISK ASSESSMENT (TOP 500)\n")
#         all_customers.to_csv(output, index=False)
#         output.write("\n\nRETURN STATISTICS BY CUSTOMER (TOP 500)\n")
#         return_stats.to_csv(output, index=False)
        
#         output.seek(0)
        
#         timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#         filename = f"refund_abuse_report_{db_type.lower()}_{timestamp}.csv"
        
#         return Response(
#             output.getvalue(),
#             mimetype="text/csv",
#             headers={
#                 "Content-Disposition": f"attachment; filename={filename}",
#                 "Content-type": "text/csv"
#             }
#         )
    
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# # ===== KEEP THIS AT THE BOTTOM =====
# if __name__ == '__main__':
#     print(f"Starting Flask app with {'LARGE' if USE_LARGE_DATABASE else 'SMALL'} database: {DB_PATH}")
#     app.run(debug=True, host='0.0.0.0', port=5000)



from flask import Flask, render_template, request, jsonify, Response, session
import sqlite3
import pandas as pd
from detection_system import RefundAbuseDetector
from detection_system_large import LargeRefundAbuseDetector
import csv
import io
from datetime import datetime
import uuid
from real_scraper import RealPriceScraper  # Add this import

from dataset_manager import DatasetPriceManager

app = Flask(__name__)
app.secret_key = 'your-secret-key-here-make-it-random'

# ===== DATABASE CONFIGURATION =====
USE_LARGE_DATABASE = True
DB_PATH = 'large_refund_abuse.db' if USE_LARGE_DATABASE else 'refund_abuse.db'


dataset_manager = DatasetPriceManager()


# ===== PRICE COMPARISON ROUTES (DIRECT IMPLEMENTATION) =====

@app.route('/price-comparison')
def price_comparison_main():
    """Main price comparison page"""
    # Initialize session for favorites
    if 'user_id' not in session:
        session['user_id'] = str(uuid.uuid4())
    
    return render_template('price_comparison.html')

# @app.route('/price-comparison/search-prices', methods=['POST'])
# def search_prices():
#     """Search prices across platforms"""
#     try:
#         print("🔍 Search endpoint called!")  # Debug line
        
#         # Initialize session
#         if 'user_id' not in session:
#             session['user_id'] = str(uuid.uuid4())
            
#         query = request.form.get('query', '').strip()
#         print(f"🔍 Search query: {query}")  # Debug line
        
#         if not query:
#             return jsonify({'error': 'Please enter a search query'}), 400
        
#         # Mock data for testing
#         mock_products = [
#             {
#                 'name': f'{query} - Brand New (Amazon)',
#                 'price': 19999.99,
#                 'original_price': 24999.99,
#                 'rating': 4.5,
#                 'review_count': 1250,
#                 'url': 'https://www.amazon.in/demo',
#                 'image_url': 'https://via.placeholder.com/150',
#                 'platform': 'Amazon'
#             },
#             {
#                 'name': f'{query} - Latest Model (Flipkart)',
#                 'price': 18999.99,
#                 'original_price': None,
#                 'rating': 4.3,
#                 'review_count': 890,
#                 'url': 'https://www.flipkart.com/demo',
#                 'image_url': 'https://via.placeholder.com/150',
#                 'platform': 'Flipkart'
#             }
#         ]
        
#         print(f"🔍 Returning {len(mock_products)} mock products")  # Debug line
#         return render_template('search_results.html', 
#                              products=mock_products, 
#                              query=query,
#                              results_count=len(mock_products))
    
#     except Exception as e:
#         print(f"❌ Search error: {e}")  # Debug line
#         return jsonify({'error': str(e)}), 500

@app.route('/price-comparison/search-prices', methods=['POST'])
def search_prices():
    """Search prices across platforms using dataset"""
    try:
        print("🔍 Search endpoint called!")
        
        # Initialize session
        if 'user_id' not in session:
            session['user_id'] = str(uuid.uuid4())
            
        query = request.form.get('query', '').strip()
        print(f"🔍 Search query: {query}")
        
        if not query:
            return jsonify({'error': 'Please enter a search query'}), 400
        
        # Use dataset for product search
        print("📊 Searching in dataset...")
        products, source = dataset_manager.search_products(query)
        
        print(f"🔍 Found {len(products)} products from dataset")
        return render_template('search_results.html', 
                             products=products, 
                             query=query,
                             results_count=len(products),
                             source=source)
    
    except Exception as e:
        print(f"❌ Search error: {e}")
        return jsonify({'error': str(e)}), 500
    

# @app.route('/price-comparison/search-prices', methods=['POST'])
# def search_prices():
#     """Search prices across platforms"""
#     try:
#         print("🔍 Search endpoint called!")
    
#         if 'user_id' not in session:
#             session['user_id'] = str(uuid.uuid4())
            
#         query = request.form.get('query', '').strip()
#         print(f"🔍 Search query: {query}")
        
#         if not query:
#             return jsonify({'error': 'Please enter a search query'}), 400
        
#         # Return SIMPLE HTML for testing
#         return f"""
#         <html>
#         <body>
#             <h1>SEARCH RESULTS PAGE - IT WORKS!</h1>
#             <h2>You searched for: {query}</h2>
#             <p>This proves the search is working!</p>
#             <a href="/price-comparison">Back to Search</a>
#         </body>
#         </html>
#         """
    
#     except Exception as e:
#         print(f"❌ Search error: {e}")
#         return jsonify({'error': str(e)}), 500

@app.route('/price-comparison/favorites')
def favorites():
    """View user's favorite products"""
    # Initialize session
    if 'user_id' not in session:
        session['user_id'] = str(uuid.uuid4())
    
    # Mock favorites for testing
    mock_favorites = [
        {
            'id': 1,
            'name': 'iPhone 15',
            'category': 'Electronics',
            'image_url': 'https://via.placeholder.com/150',
            'favorited_at': '2024-01-09',
            'platforms': ['Amazon', 'Flipkart'],
            'best_price': 18999.99
        },
        {
            'id': 2,
            'name': 'Nike Running Shoes',
            'category': 'Footwear',
            'image_url': 'https://via.placeholder.com/150',
            'favorited_at': '2024-01-08',
            'platforms': ['Myntra', 'Flipkart'],
            'best_price': 4599.99
        }
    ]
    
    return render_template('favorites.html', favorites=mock_favorites)

@app.route('/price-comparison/add-favorite', methods=['POST'])
def add_favorite():
    """Add product to favorites"""
    try:
        if 'user_id' not in session:
            session['user_id'] = str(uuid.uuid4())
            
        product_name = request.form.get('product_name')
        # In a real app, you'd save to database here
        
        return jsonify({'success': True, 'message': 'Added to favorites'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ===== REFUND ABUSE ROUTES =====

@app.route('/')
def dashboard():
    """Main refund abuse dashboard"""
    conn = sqlite3.connect(DB_PATH)
    
    # For large databases, add pagination
    page = request.args.get('page', 1, type=int)
    per_page = 50 if USE_LARGE_DATABASE else 100
    offset = (page - 1) * per_page
    
    if USE_LARGE_DATABASE:
        flagged_customers = pd.read_sql_query(f"""
        SELECT c.id, c.email, c.name, c.risk_score, af.severity, af.flag_reason, af.created_at
        FROM customers c
        JOIN abuse_flags af ON c.id = af.customer_id
        WHERE af.is_active = TRUE
        ORDER BY c.risk_score DESC
        LIMIT {per_page} OFFSET {offset}
        """, conn)
        
        # Get total count for pagination
        total_count = pd.read_sql_query("""
        SELECT COUNT(*) as total FROM abuse_flags WHERE is_active = TRUE
        """, conn).iloc[0]['total']
        total_pages = (total_count + per_page - 1) // per_page
    else:
        flagged_customers = pd.read_sql_query("""
        SELECT c.id, c.email, c.name, c.risk_score, af.severity, af.flag_reason, af.created_at
        FROM customers c
        JOIN abuse_flags af ON c.id = af.customer_id
        WHERE af.is_active = TRUE
        ORDER BY c.risk_score DESC
        """, conn)
        total_pages = 1
    
    # Enhanced stats for both databases
    stats = pd.read_sql_query(f"""
    SELECT 
        COUNT(*) as total_customers,
        SUM(CASE WHEN is_flagged THEN 1 ELSE 0 END) as flagged_customers,
        AVG(risk_score) as avg_risk_score,
        (SELECT COUNT(*) FROM returns WHERE return_date >= datetime('now', '-30 days')) as recent_returns_30d,
        (SELECT COUNT(*) FROM returns) as total_returns
    FROM customers
    """, conn)
    
    conn.close()
    
    return render_template('dashboard.html', 
                         customers=flagged_customers.to_dict('records'),
                         stats=stats.to_dict('records')[0],
                         current_page=page,
                         total_pages=total_pages,
                         use_large_db=USE_LARGE_DATABASE)

@app.route('/scan')
def scan_customers():
    """Run refund abuse scan"""
    # Use appropriate detector based on database size
    if USE_LARGE_DATABASE:
        detector = LargeRefundAbuseDetector(DB_PATH)
    else:
        detector = RefundAbuseDetector(DB_PATH)
    
    flagged = detector.scan_for_abuse(days=90)
    
    # For large databases, return only summary to avoid performance issues
    if USE_LARGE_DATABASE:
        return jsonify({
            'message': f'Scan completed. Found {len(flagged)} suspicious customers.',
            'flagged_count': len(flagged),
            'top_customers': flagged[:10]
        })
    else:
        return jsonify({
            'message': f'Scan completed. Found {len(flagged)} suspicious customers.',
            'flagged_customers': flagged
        })

@app.route('/customer/<int:customer_id>')
def customer_detail(customer_id):
    """Get detailed customer information"""
    try:
        conn = sqlite3.connect(DB_PATH)
        
        # Customer basic info
        customer_info = pd.read_sql_query("""
        SELECT 
            c.id, c.name, c.email, c.phone, c.risk_score, c.created_at,
            COUNT(DISTINCT o.id) as total_orders,
            COUNT(DISTINCT r.id) as total_returns,
            ROUND(CAST(COUNT(DISTINCT r.id) AS FLOAT) / COUNT(DISTINCT o.id) * 100, 2) as return_rate
        FROM customers c
        LEFT JOIN orders o ON c.id = o.customer_id
        LEFT JOIN returns r ON o.id = r.order_id
        WHERE c.id = ?
        GROUP BY c.id, c.name, c.email, c.phone, c.risk_score, c.created_at
        """, conn, params=[customer_id])
        
        # Recent returns (last 90 days)
        recent_returns = pd.read_sql_query("""
        SELECT 
            r.return_date, r.return_reason, r.refund_amount, r.return_status,
            o.order_date, o.total_amount
        FROM returns r
        JOIN orders o ON r.order_id = o.id
        WHERE r.customer_id = ? 
        AND r.return_date >= datetime('now', '-90 days')
        ORDER BY r.return_date DESC
        LIMIT 20
        """, conn, params=[customer_id])
        
        conn.close()
        
        return jsonify({
            'customer_info': customer_info.to_dict('records')[0] if not customer_info.empty else {},
            'recent_returns': recent_returns.to_dict('records')
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/stats')
def get_detailed_stats():
    """Get detailed statistics for large database"""
    try:
        conn = sqlite3.connect(DB_PATH)
        
        # Comprehensive statistics
        stats = pd.read_sql_query("""
        WITH return_stats AS (
            SELECT 
                COUNT(*) as total_returns,
                AVG(refund_amount) as avg_refund,
                COUNT(DISTINCT customer_id) as customers_with_returns,
                SUM(CASE WHEN return_date >= datetime('now', '-30 days') THEN 1 ELSE 0 END) as returns_30d
            FROM returns
        ),
        customer_stats AS (
            SELECT
                COUNT(*) as total_customers,
                AVG(risk_score) as avg_risk_score,
                SUM(CASE WHEN risk_score >= 70 THEN 1 ELSE 0 END) as high_risk_customers,
                SUM(CASE WHEN risk_score BETWEEN 40 AND 69 THEN 1 ELSE 0 END) as medium_risk_customers
            FROM customers
        )
        SELECT * FROM return_stats, customer_stats
        """, conn)
        
        # Top 10 highest risk customers
        top_risky = pd.read_sql_query("""
        SELECT name, email, risk_score, severity, flag_reason
        FROM customers c
        JOIN abuse_flags af ON c.id = af.customer_id
        WHERE af.is_active = TRUE
        ORDER BY risk_score DESC
        LIMIT 10
        """, conn)
        
        conn.close()
        
        return jsonify({
            'statistics': stats.to_dict('records')[0],
            'top_risky_customers': top_risky.to_dict('records')
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ===== EXPORT ROUTES =====

@app.route('/export/flagged_customers')
def export_flagged_customers():
    """Export flagged customers to CSV"""
    try:
        conn = sqlite3.connect(DB_PATH)
        
        # For large databases, we might want to limit or batch exports
        if USE_LARGE_DATABASE:
            query = """
            SELECT 
                c.id as "Customer ID",
                c.name as "Customer Name",
                c.email as "Email",
                c.phone as "Phone",
                c.risk_score as "Risk Score",
                af.severity as "Severity",
                af.flag_reason as "Flag Reasons",
                af.created_at as "Flag Date"
            FROM customers c
            JOIN abuse_flags af ON c.id = af.customer_id
            WHERE af.is_active = TRUE
            ORDER BY c.risk_score DESC
            LIMIT 1000
            """
        else:
            query = """
            SELECT 
                c.id as "Customer ID",
                c.name as "Customer Name",
                c.email as "Email",
                c.phone as "Phone",
                c.risk_score as "Risk Score",
                af.severity as "Severity",
                af.flag_reason as "Flag Reasons",
                af.created_at as "Flag Date",
                c.created_at as "Customer Since"
            FROM customers c
            JOIN abuse_flags af ON c.id = af.customer_id
            WHERE af.is_active = TRUE
            ORDER BY c.risk_score DESC
            """
        
        flagged_customers = pd.read_sql_query(query, conn)
        conn.close()
        
        # Create CSV in memory
        output = io.StringIO()
        flagged_customers.to_csv(output, index=False)
        output.seek(0)
        
        # Create filename with timestamp and database type
        db_type = "large" if USE_LARGE_DATABASE else "small"
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"flagged_customers_{db_type}_{timestamp}.csv"
        
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "Content-type": "text/csv"
            }
        )
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/export/customer_details/<int:customer_id>')
def export_customer_details(customer_id):
    """Export detailed customer history to CSV"""
    try:
        conn = sqlite3.connect(DB_PATH)
        
        # Get customer basic info
        customer_info = pd.read_sql_query("""
        SELECT 
            name as "Customer Name",
            email as "Email",
            phone as "Phone",
            risk_score as "Risk Score",
            created_at as "Customer Since"
        FROM customers 
        WHERE id = ?
        """, conn, params=[customer_id])
        
        # Get customer order and return history with limits for large DB
        limit_clause = "LIMIT 500" if USE_LARGE_DATABASE else ""
        
        customer_history = pd.read_sql_query(f"""
        SELECT 
            o.id as "Order ID",
            o.order_date as "Order Date",
            o.total_amount as "Order Amount",
            r.return_date as "Return Date",
            r.return_reason as "Return Reason",
            r.refund_amount as "Refund Amount",
            r.return_status as "Return Status",
            CASE WHEN r.id IS NOT NULL THEN 'Yes' ELSE 'No' END as "Item Returned"
        FROM orders o
        LEFT JOIN returns r ON o.id = r.order_id
        WHERE o.customer_id = ?
        ORDER BY o.order_date DESC
        {limit_clause}
        """, conn, params=[customer_id])
        
        conn.close()
        
        # Create CSV with multiple sections
        output = io.StringIO()
        
        # Write customer info section
        output.write("CUSTOMER INFORMATION\n")
        customer_info.to_csv(output, index=False)
        output.write("\n\nORDER AND RETURN HISTORY\n")
        customer_history.to_csv(output, index=False)
        
        output.seek(0)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"customer_{customer_id}_details_{timestamp}.csv"
        
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "Content-type": "text/csv"
            }
        )
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/export/all_data')
def export_all_data():
    """Export comprehensive report with all data"""
    try:
        conn = sqlite3.connect(DB_PATH)
        
        # For large databases, use more efficient queries
        if USE_LARGE_DATABASE:
            # 1. System Summary (optimized)
            summary = pd.read_sql_query("""
            SELECT 
                (SELECT COUNT(*) FROM customers) as "Total Customers",
                (SELECT COUNT(*) FROM abuse_flags WHERE is_active = TRUE) as "Flagged Customers",
                (SELECT AVG(risk_score) FROM customers) as "Average Risk Score",
                (SELECT COUNT(*) FROM returns WHERE return_date >= datetime('now', '-30 days')) as "Returns Last 30 Days",
                (SELECT AVG(refund_amount) FROM returns) as "Average Refund Amount",
                (SELECT COUNT(*) FROM returns) as "Total Returns"
            """, conn)
            
            # 2. Top 500 customers by risk score
            all_customers = pd.read_sql_query("""
            SELECT 
                id as "Customer ID",
                name as "Name",
                email as "Email",
                risk_score as "Risk Score",
                is_flagged as "Is Flagged",
                created_at as "Customer Since"
            FROM customers
            ORDER BY risk_score DESC
            LIMIT 500
            """, conn)
            
            # 3. Return statistics by customer (top 500 by return rate)
            return_stats = pd.read_sql_query("""
            SELECT 
                c.id as "Customer ID",
                c.name as "Customer Name",
                COUNT(DISTINCT o.id) as "Total Orders",
                COUNT(DISTINCT r.id) as "Total Returns",
                ROUND(CAST(COUNT(DISTINCT r.id) AS FLOAT) / COUNT(DISTINCT o.id) * 100, 2) as "Return Rate %",
                AVG(r.refund_amount) as "Average Refund Amount",
                MAX(r.return_date) as "Last Return Date"
            FROM customers c
            LEFT JOIN orders o ON c.id = o.customer_id
            LEFT JOIN returns r ON o.id = r.order_id
            GROUP BY c.id, c.name
            HAVING COUNT(DISTINCT r.id) > 0
            ORDER BY "Return Rate %" DESC
            LIMIT 500
            """, conn)
        else:
            # Original queries for small database
            summary = pd.read_sql_query("""
            SELECT 
                COUNT(*) as "Total Customers",
                SUM(CASE WHEN is_flagged THEN 1 ELSE 0 END) as "Flagged Customers",
                AVG(risk_score) as "Average Risk Score",
                (SELECT COUNT(*) FROM returns WHERE return_date >= datetime('now', '-30 days')) as "Returns Last 30 Days",
                (SELECT AVG(refund_amount) FROM returns) as "Average Refund Amount"
            FROM customers
            """, conn)
            
            all_customers = pd.read_sql_query("""
            SELECT 
                id as "Customer ID",
                name as "Name",
                email as "Email",
                risk_score as "Risk Score",
                is_flagged as "Is Flagged",
                created_at as "Customer Since"
            FROM customers
            ORDER BY risk_score DESC
            """, conn)
            
            return_stats = pd.read_sql_query("""
            SELECT 
                c.id as "Customer ID",
                c.name as "Customer Name",
                COUNT(DISTINCT o.id) as "Total Orders",
                COUNT(DISTINCT r.id) as "Total Returns",
                ROUND(CAST(COUNT(DISTINCT r.id) AS FLOAT) / COUNT(DISTINCT o.id) * 100, 2) as "Return Rate %",
                AVG(r.refund_amount) as "Average Refund Amount",
                MAX(r.return_date) as "Last Return Date"
            FROM customers c
            LEFT JOIN orders o ON c.id = o.customer_id
            LEFT JOIN returns r ON o.id = r.order_id
            GROUP BY c.id, c.name
            HAVING COUNT(DISTINCT r.id) > 0
            ORDER BY "Return Rate %" DESC
            """, conn)
        
        conn.close()
        
        # Create comprehensive CSV
        output = io.StringIO()
        
        db_type = "LARGE" if USE_LARGE_DATABASE else "SMALL"
        output.write(f"REFUND ABUSE DETECTION SYSTEM - COMPREHENSIVE REPORT ({db_type} DATABASE)\n")
        output.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        output.write("SYSTEM SUMMARY\n")
        summary.to_csv(output, index=False)
        output.write("\n\nCUSTOMERS RISK ASSESSMENT (TOP 500)\n")
        all_customers.to_csv(output, index=False)
        output.write("\n\nRETURN STATISTICS BY CUSTOMER (TOP 500)\n")
        return_stats.to_csv(output, index=False)
        
        output.seek(0)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"refund_abuse_report_{db_type.lower()}_{timestamp}.csv"
        
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "Content-type": "text/csv"
            }
        )
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("🚀 Flask App Started Successfully!")
    print("📍 Available Routes:")
    print("   - http://localhost:5000/ (Refund Abuse Dashboard)")
    print("   - http://localhost:5000/price-comparison (Price Comparison)")
    print("   - http://localhost:5000/price-comparison/search-prices (Search Products)")
    print("   - http://localhost:5000/price-comparison/favorites (Favorites)")
    print("   - http://localhost:5000/scan (Run Refund Scan)")
    print("   - http://localhost:5000/stats (Detailed Statistics)")
    print(f"📊 Using {'LARGE' if USE_LARGE_DATABASE else 'SMALL'} database: {DB_PATH}")
    app.run(debug=True, host='0.0.0.0', port=5000)