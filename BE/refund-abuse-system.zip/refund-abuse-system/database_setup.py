import sqlite3
import os

def setup_database():
    """Initialize the database with required tables"""
    
    # Remove existing database if you want a fresh start
    if os.path.exists('refund_abuse.db'):
        os.remove('refund_abuse.db')
    
    conn = sqlite3.connect('refund_abuse.db')
    cursor = conn.cursor()
    
    # Customers table
    cursor.execute('''
    CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        phone VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        risk_score INTEGER DEFAULT 0,
        is_flagged BOOLEAN DEFAULT FALSE
    )
    ''')
    
    # Orders table
    cursor.execute('''
    CREATE TABLE orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        total_amount DECIMAL(10,2),
        status VARCHAR(20) DEFAULT 'completed',
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    )
    ''')
    
    # Returns table
    cursor.execute('''
    CREATE TABLE returns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER,
        customer_id INTEGER,
        return_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        return_reason TEXT,
        refund_amount DECIMAL(10,2),
        return_status VARCHAR(20) DEFAULT 'approved',
        items_returned TEXT,
        FOREIGN KEY (order_id) REFERENCES orders(id),
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    )
    ''')
    
    # Abuse flags table
    cursor.execute('''
    CREATE TABLE abuse_flags (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        flag_reason TEXT,
        severity VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        resolved_at TIMESTAMP NULL,
        is_active BOOLEAN DEFAULT TRUE,
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    )
    ''')
    
    conn.commit()
    conn.close()
    print("Database setup completed successfully!")

if __name__ == "__main__":
    setup_database()