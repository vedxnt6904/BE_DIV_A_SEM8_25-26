import sqlite3
import random
from datetime import datetime, timedelta
import names
from faker import Faker
import pandas as pd

def generate_large_dataset(num_customers=1000, num_orders=5000, return_rate=0.15):
    """Generate a large realistic e-commerce dataset"""
    
    # Install faker if not already installed: pip install faker
    
    fake = Faker()
    conn = sqlite3.connect('large_refund_abuse.db')
    cursor = conn.cursor()
    
    # Create tables (same schema as before)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        phone VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        risk_score INTEGER DEFAULT 0,
        is_flagged BOOLEAN DEFAULT FALSE
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        total_amount DECIMAL(10,2),
        status VARCHAR(20) DEFAULT 'completed',
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS returns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER,
        customer_id INTEGER,
        return_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        return_reason TEXT,
        refund_amount DECIMAL(10,2),
        return_status VARCHAR(20) DEFAULT 'approved',
        items_returned TEXT,
        FOREIGN KEY (order_id) REFERENCES orders(id),
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS abuse_flags (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        flag_reason TEXT,
        severity VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        resolved_at TIMESTAMP NULL,
        is_active BOOLEAN DEFAULT TRUE,
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    )
    ''')
    
    print("Generating customers...")
    # Generate customers
    customers = []
    for i in range(num_customers):
        first_name = names.get_first_name()
        last_name = names.get_last_name()
        email = f"{first_name.lower()}.{last_name.lower()}{i}@example.com"
        phone = f"555-{random.randint(100,999)}-{random.randint(1000,9999)}"
        customers.append((email, f"{first_name} {last_name}", phone))
    
    cursor.executemany(
        "INSERT INTO customers (email, name, phone) VALUES (?, ?, ?)",
        customers
    )
    
    print("Generating orders...")
    # Generate orders
    cursor.execute("SELECT id FROM customers")
    customer_ids = [row[0] for row in cursor.fetchall()]
    
    orders = []
    for i in range(num_orders):
        customer_id = random.choice(customer_ids)
        order_date = datetime.now() - timedelta(days=random.randint(1, 365))
        total_amount = round(random.uniform(25, 500), 2)
        orders.append((customer_id, order_date.strftime('%Y-%m-%d %H:%M:%S'), total_amount, 'completed'))
    
    cursor.executemany(
        "INSERT INTO orders (customer_id, order_date, total_amount, status) VALUES (?, ?, ?, ?)",
        orders
    )
    
    print("Generating returns...")
    # Generate returns with realistic patterns
    cursor.execute("SELECT id, customer_id, total_amount, order_date FROM orders")
    orders_data = cursor.fetchall()
    
    returns = []
    return_reasons = [
        'Changed mind', 'Wrong size', 'Defective product', 
        'Not as described', 'Better price available', 'Received wrong item'
    ]
    
    # Create some abusive customers (5% of customers)
    abusive_customer_ids = random.sample(customer_ids, max(1, num_customers // 20))
    
    for order_id, customer_id, total_amount, order_date_str in orders_data:
        is_abusive = customer_id in abusive_customer_ids
        should_return = False
        
        if is_abusive:
            # Abusive customers return 60-90% of orders
            should_return = random.random() < random.uniform(0.6, 0.9)
        else:
            # Normal customers return 5-20% of orders
            should_return = random.random() < return_rate
        
        if should_return:
            # Convert order_date string back to datetime for calculation
            order_date = datetime.strptime(order_date_str, '%Y-%m-%d %H:%M:%S')
            
            days_to_return = random.randint(1, 30) if is_abusive else random.randint(1, 60)
            return_date = order_date + timedelta(days=days_to_return)
            
            if return_date > datetime.now():
                continue  # Skip future returns
                
            refund_amount = total_amount * random.uniform(0.7, 1.0)
            reason = random.choice(return_reasons)
            
            returns.append((
                order_id, customer_id, return_date.strftime('%Y-%m-%d %H:%M:%S'), reason, 
                refund_amount, 'approved', f"{random.randint(1, 3)} items"
            ))
    
    if returns:  # Only insert if there are returns
        cursor.executemany('''
        INSERT INTO returns (order_id, customer_id, return_date, return_reason, refund_amount, return_status, items_returned)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', returns)
    
    conn.commit()
    
    # Print statistics
    cursor.execute("SELECT COUNT(*) FROM customers")
    print(f"Total customers: {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM orders")
    print(f"Total orders: {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM returns")
    print(f"Total returns: {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(DISTINCT customer_id) FROM returns")
    print(f"Customers with returns: {cursor.fetchone()[0]}")
    
    # Print abusive customers info
    print(f"Abusive customers created: {len(abusive_customer_ids)}")
    
    conn.close()
    print("Large dataset generated successfully!")

if __name__ == "__main__":
    generate_large_dataset(num_customers=1000, num_orders=5000, return_rate=0.15)