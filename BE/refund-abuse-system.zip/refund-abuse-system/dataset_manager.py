# # import pandas as pd
# # import os
# # import random

# # class DatasetPriceManager:
# #     def __init__(self):
# #         self.dataset_path = "data/products_dataset.csv"
# #         self.load_dataset()
    
# #     def load_dataset(self):
# #         """Load or create sample dataset"""
# #         if not os.path.exists(self.dataset_path):
# #             self.create_sample_dataset()
        
# #         self.df = pd.read_csv(self.dataset_path)
# #         print("✅ Dataset loaded successfully!")
    
# #     def create_sample_dataset(self):
# #         """Create a sample dataset with realistic products"""
# #         os.makedirs("data", exist_ok=True)
        
# #         # Sample products with variations across platforms
# #         sample_products = [
# #             # Smartphones
# #             {"name": "iPhone 14", "category": "smartphone", "brand": "Apple", "base_price": 79900},
# #             {"name": "Samsung Galaxy S23", "category": "smartphone", "brand": "Samsung", "base_price": 74900},
# #             {"name": "OnePlus 11", "category": "smartphone", "brand": "OnePlus", "base_price": 56900},
# #             {"name": "Google Pixel 7", "category": "smartphone", "brand": "Google", "base_price": 59900},
# #             {"name": "Xiaomi 13 Pro", "category": "smartphone", "brand": "Xiaomi", "base_price": 79900},
            
# #             # Laptops
# #             {"name": "MacBook Air M2", "category": "laptop", "brand": "Apple", "base_price": 114900},
# #             {"name": "Dell XPS 13", "category": "laptop", "brand": "Dell", "base_price": 124990},
# #             {"name": "HP Pavilion", "category": "laptop", "brand": "HP", "base_price": 65990},
# #             {"name": "Lenovo ThinkPad", "category": "laptop", "brand": "Lenovo", "base_price": 84900},
# #             {"name": "Asus Zenbook", "category": "laptop", "brand": "Asus", "base_price": 89900},
            
# #             # Headphones
# #             {"name": "Sony WH-1000XM4", "category": "headphone", "brand": "Sony", "base_price": 24990},
# #             {"name": "Bose QuietComfort", "category": "headphone", "brand": "Bose", "base_price": 28900},
# #             {"name": "Apple AirPods Pro", "category": "headphone", "brand": "Apple", "base_price": 24900},
# #             {"name": "JBL Wave 200", "category": "headphone", "brand": "JBL", "base_price": 5990},
# #             {"name": "Sennheiser HD 450", "category": "headphone", "brand": "Sennheiser", "base_price": 12990},
            
# #             # TVs
# #             {"name": "Samsung 55 inch 4K TV", "category": "tv", "brand": "Samsung", "base_price": 54900},
# #             {"name": "LG OLED TV", "category": "tv", "brand": "LG", "base_price": 89900},
# #             {"name": "Sony Bravia", "category": "tv", "brand": "Sony", "base_price": 74900},
# #             {"name": "Mi TV 5X", "category": "tv", "brand": "Xiaomi", "base_price": 41999},
# #             {"name": "OnePlus TV", "category": "tv", "brand": "OnePlus", "base_price": 39999},
# #         ]
        
# #         all_products = []
# #         product_id = 1
        
# #         platforms = ["Amazon", "Flipkart", "Reliance Digital", "Croma", "Vijay Sales"]
        
# #         for product in sample_products:
# #             for platform in platforms:
# #                 # Create price variations for each platform
# #                 price_variation = random.uniform(0.8, 1.1)  # 80% to 110% of base price
# #                 current_price = int(product["base_price"] * price_variation)
                
# #                 # Sometimes add discounts
# #                 original_price = current_price
# #                 if random.random() > 0.3:  # 70% chance of discount
# #                     original_price = int(current_price * random.uniform(1.1, 1.3))
                
# #                 all_products.append({
# #                     "product_id": product_id,
# #                     "product_name": product["name"],
# #                     "category": product["category"],
# #                     "brand": product["brand"],
# #                     "price": current_price,
# #                     "original_price": original_price,
# #                     "rating": round(random.uniform(3.8, 4.8), 1),
# #                     "reviews": random.randint(500, 10000),
# #                     "platform": platform,
# #                     "in_stock": random.choice([True, True, True, False]),  # 75% in stock
# #                     "delivery_time": random.choice(["1-2 days", "2-3 days", "3-5 days", "1 week"])
# #                 })
# #                 product_id += 1
        
# #         df = pd.DataFrame(all_products)
        
# #         # Add URLs and images
# #         df['url'] = 'https://example.com/product/' + df['product_name'].str.replace(' ', '-') + '-' + df['platform'].str.replace(' ', '')
# #         df['image_url'] = 'https://picsum.photos/200/200?random=' + df['product_id'].astype(str)
        
# #         df.to_csv(self.dataset_path, index=False)
# #         print(f"✅ Created sample dataset with {len(df)} products!")
    
# #     def search_products(self, query):
# #         """Search products in dataset"""
# #         if not query:
# #             return [], "dataset"
        
# #         query_lower = query.lower().strip()
        
# #         # Search in product names, categories, and brands
# #         mask = (
# #             self.df['product_name'].str.lower().str.contains(query_lower, na=False) |
# #             self.df['category'].str.lower().str.contains(query_lower, na=False) |
# #             self.df['brand'].str.lower().str.contains(query_lower, na=False)
# #         )
        
# #         results = self.df[mask]
        
# #         if len(results) == 0:
# #             return [], "dataset"
        
# #         products = []
# #         for _, row in results.iterrows():
# #             discount = 0
# #             if row['original_price'] > row['price']:
# #                 discount = int(((row['original_price'] - row['price']) / row['original_price']) * 100)
            
# #             products.append({
# #                 'id': row['product_id'],
# #                 'name': row['product_name'],
# #                 'price': float(row['price']),
# #                 'original_price': float(row['original_price']),
# #                 'discount_percentage': discount,
# #                 'rating': float(row['rating']),
# #                 'review_count': int(row['reviews']),
# #                 'platform': row['platform'],
# #                 'url': row['url'],
# #                 'image_url': row['image_url'],
# #                 'in_stock': row['in_stock'],
# #                 'delivery': row['delivery_time'],
# #                 'category': row['category'],
# #                 'brand': row['brand']
# #             })
        
# #         # Sort by price (lowest first)
# #         products.sort(key=lambda x: x['price'])
        
# #         return products, "dataset"




# import pandas as pd
# import os
# import random
# from datetime import datetime

# class DatasetPriceManager:
#     def __init__(self):
#         self.dataset_path = "data/products_dataset.csv"
#         self.load_dataset()
    
#     def load_dataset(self):
#         """Load or create sample dataset"""
#         if not os.path.exists(self.dataset_path):
#             self.create_sample_dataset()
        
#         self.df = pd.read_csv(self.dataset_path)
#         print("✅ Price comparison dataset loaded successfully!")
    
#     def create_sample_dataset(self):
#         """Create a realistic sample dataset with Indian prices"""
#         os.makedirs("data", exist_ok=True)
        
#         # Sample products with realistic Indian e-commerce data
#         sample_products = [
#             # Smartphones
#             {"name": "iPhone 15 Pro", "category": "smartphone", "brand": "Apple", "base_price": 134900},
#             {"name": "iPhone 15", "category": "smartphone", "brand": "Apple", "base_price": 79900},
#             {"name": "Samsung Galaxy S23 Ultra", "category": "smartphone", "brand": "Samsung", "base_price": 124999},
#             {"name": "Samsung Galaxy Z Flip5", "category": "smartphone", "brand": "Samsung", "base_price": 99999},
#             {"name": "OnePlus 11", "category": "smartphone", "brand": "OnePlus", "base_price": 56999},
#             {"name": "OnePlus Nord 3", "category": "smartphone", "brand": "OnePlus", "base_price": 33999},
#             {"name": "Google Pixel 8 Pro", "category": "smartphone", "brand": "Google", "base_price": 106999},
#             {"name": "Google Pixel 7a", "category": "smartphone", "brand": "Google", "base_price": 43999},
#             {"name": "Xiaomi 13 Pro", "category": "smartphone", "brand": "Xiaomi", "base_price": 79999},
#             {"name": "Redmi Note 13 Pro", "category": "smartphone", "brand": "Xiaomi", "base_price": 25999},
#             {"name": "Vivo V29", "category": "smartphone", "brand": "Vivo", "base_price": 33990},
#             {"name": "Oppo Reno 10", "category": "smartphone", "brand": "Oppo", "base_price": 32999},
            
#             # Laptops
#             {"name": "MacBook Air M2", "category": "laptop", "brand": "Apple", "base_price": 114900},
#             {"name": "MacBook Pro 14-inch", "category": "laptop", "brand": "Apple", "base_price": 199900},
#             {"name": "Dell XPS 13", "category": "laptop", "brand": "Dell", "base_price": 124990},
#             {"name": "Dell Inspiron 15", "category": "laptop", "brand": "Dell", "base_price": 54990},
#             {"name": "HP Pavilion", "category": "laptop", "brand": "HP", "base_price": 65990},
#             {"name": "HP Victus Gaming", "category": "laptop", "brand": "HP", "base_price": 74990},
#             {"name": "Lenovo ThinkPad", "category": "laptop", "brand": "Lenovo", "base_price": 84900},
#             {"name": "Lenovo IdeaPad", "category": "laptop", "brand": "Lenovo", "base_price": 42990},
#             {"name": "Asus Zenbook", "category": "laptop", "brand": "Asus", "base_price": 89900},
#             {"name": "Asus TUF Gaming", "category": "laptop", "brand": "Asus", "base_price": 69990},
            
#             # Headphones
#             {"name": "Sony WH-1000XM5", "category": "headphone", "brand": "Sony", "base_price": 29990},
#             {"name": "Sony WH-CH720N", "category": "headphone", "brand": "Sony", "base_price": 11990},
#             {"name": "Bose QuietComfort Ultra", "category": "headphone", "brand": "Bose", "base_price": 35900},
#             {"name": "Bose QuietComfort 45", "category": "headphone", "brand": "Bose", "base_price": 28900},
#             {"name": "Apple AirPods Pro (2nd Gen)", "category": "headphone", "brand": "Apple", "base_price": 24900},
#             {"name": "Apple AirPods 3rd Gen", "category": "headphone", "brand": "Apple", "base_price": 19900},
#             {"name": "JBL Wave Beam", "category": "headphone", "brand": "JBL", "base_price": 5990},
#             {"name": "JBL Tune 770NC", "category": "headphone", "brand": "JBL", "base_price": 7990},
#             {"name": "Sennheiser HD 450BT", "category": "headphone", "brand": "Sennheiser", "base_price": 12990},
#             {"name": "Sennheiser Accentum", "category": "headphone", "brand": "Sennheiser", "base_price": 14990},
            
#             # TVs
#             {"name": "Samsung 55 inch 4K Smart TV", "category": "tv", "brand": "Samsung", "base_price": 54900},
#             {"name": "Samsung 65 inch QLED TV", "category": "tv", "brand": "Samsung", "base_price": 124999},
#             {"name": "LG 55 inch OLED TV", "category": "tv", "brand": "LG", "base_price": 89900},
#             {"name": "LG 43 inch Smart TV", "category": "tv", "brand": "LG", "base_price": 32900},
#             {"name": "Sony Bravia 55 inch 4K", "category": "tv", "brand": "Sony", "base_price": 74900},
#             {"name": "Sony Bravia 65 inch", "category": "tv", "brand": "Sony", "base_price": 104999},
#             {"name": "Mi TV 5X 55 inch", "category": "tv", "brand": "Xiaomi", "base_price": 41999},
#             {"name": "Mi TV 4A 32 inch", "category": "tv", "brand": "Xiaomi", "base_price": 13999},
#             {"name": "OnePlus TV 55 inch", "category": "tv", "brand": "OnePlus", "base_price": 39999},
#             {"name": "OnePlus TV 43 inch", "category": "tv", "brand": "OnePlus", "base_price": 26999},
#         ]
        
#         all_products = []
#         product_id = 1
        
#         platforms = ["Amazon", "Flipkart", "Reliance Digital", "Croma", "Vijay Sales"]
        
#         for product in sample_products:
#             for platform in platforms:
#                 # Create realistic price variations for each platform
#                 price_multiplier = random.uniform(0.85, 1.15)  # 85% to 115% of base price
#                 current_price = int(product["base_price"] * price_multiplier)
                
#                 # Add discounts (60% chance)
#                 original_price = current_price
#                 if random.random() > 0.4:
#                     discount_multiplier = random.uniform(1.1, 1.4)  # 10% to 40% discount
#                     original_price = int(current_price * discount_multiplier)
                
#                 # Realistic ratings and reviews
#                 rating = round(random.uniform(3.8, 4.8), 1)
#                 reviews = random.randint(500, 20000)
                
#                 # Delivery times based on platform
#                 delivery_times = {
#                     "Amazon": ["1-2 days", "Tomorrow", "2 days"],
#                     "Flipkart": ["2-3 days", "3-4 days"],
#                     "Reliance Digital": ["3-5 days", "1 week"],
#                     "Croma": ["2-4 days", "3-5 days"],
#                     "Vijay Sales": ["3-6 days", "1 week"]
#                 }
                
#                 all_products.append({
#                     "product_id": product_id,
#                     "product_name": product["name"],
#                     "category": product["category"],
#                     "brand": product["brand"],
#                     "price": current_price,
#                     "original_price": original_price,
#                     "rating": rating,
#                     "reviews": reviews,
#                     "platform": platform,
#                     "in_stock": random.choice([True, True, True, False]),  # 75% in stock
#                     "delivery_time": random.choice(delivery_times[platform]),
#                     "warranty": random.choice(["1 Year", "2 Years", "No Warranty", "Brand Warranty"])
#                 })
#                 product_id += 1
        
#         df = pd.DataFrame(all_products)
        
#         # Add URLs and images
#         df['url'] = 'https://example.com/product/' + df['product_name'].str.replace(' ', '-') + '-' + df['platform'].str.replace(' ', '')
#         df['image_url'] = 'https://picsum.photos/200/200?random=' + df['product_id'].astype(str)
        
#         df.to_csv(self.dataset_path, index=False)
#         print(f"✅ Created sample dataset with {len(df)} products across {len(platforms)} platforms!")
    
#     def search_products(self, query):
#         """Search products in dataset"""
#         if not query:
#             return [], "dataset"
        
#         query_lower = query.lower().strip()
        
#         # Search in product names, categories, and brands
#         mask = (
#             self.df['product_name'].str.lower().str.contains(query_lower, na=False) |
#             self.df['category'].str.lower().str.contains(query_lower, na=False) |
#             self.df['brand'].str.lower().str.contains(query_lower, na=False)
#         )
        
#         results = self.df[mask]
        
#         if len(results) == 0:
#             return [], "dataset"
        
#         products = []
#         for _, row in results.iterrows():
#             discount = 0
#             if row['original_price'] > row['price']:
#                 discount = int(((row['original_price'] - row['price']) / row['original_price']) * 100)
            
#             products.append({
#                 'id': row['product_id'],
#                 'name': row['product_name'],
#                 'price': float(row['price']),
#                 'original_price': float(row['original_price']),
#                 'discount_percentage': discount,
#                 'rating': float(row['rating']),
#                 'review_count': int(row['reviews']),
#                 'platform': row['platform'],
#                 'url': row['url'],
#                 'image_url': row['image_url'],
#                 'in_stock': row['in_stock'],
#                 'delivery': row['delivery_time'],
#                 'category': row['category'],
#                 'brand': row['brand'],
#                 'warranty': row['warranty']
#             })
        
#         # Sort by price (lowest first)
#         products.sort(key=lambda x: x['price'])
        
#         return products, "dataset"
    
#     def get_product_categories(self):
#         """Get all available product categories"""
#         return self.df['category'].unique().tolist()
    
#     def get_popular_searches(self):
#         """Get popular search suggestions"""
#         return ["iPhone", "Samsung", "Laptop", "Headphones", "TV", "OnePlus", "MacBook"]




# import pandas as pd
# import os
# import random
# from datetime import datetime

# class DatasetPriceManager:
#     def __init__(self):
#         self.dataset_path = "data/products_dataset.csv"
#         self.load_dataset()
    
#     def load_dataset(self):
#         """Load or create sample dataset"""
#         if not os.path.exists(self.dataset_path):
#             self.create_sample_dataset()
        
#         self.df = pd.read_csv(self.dataset_path)
#         print("✅ Price comparison dataset loaded successfully!")
    
#     def get_realistic_product_image(self, product_name, brand, category):
#         """Get realistic product images from free sources"""
        
#         # Convert to lowercase for matching
#         product_lower = product_name.lower()
#         brand_lower = brand.lower()
        
#         # Comprehensive image mapping for common products
#         image_mapping = {
#             # Apple Products
#             "iphone 15 pro": "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-15-pro-finish-select-202309-6-7inch-naturaltitanium?wid=5120&hei=2880&fmt=p-jpg",
#             "iphone 15": "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-15-finish-select-202309-6-1inch-pink?wid=5120&hei=2880&fmt=p-jpg",
#             "iphone 14": "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-14-finish-select-202209-6-1inch-blue?wid=5120&hei=2880&fmt=p-jpg",
#             "iphone 13": "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-13-blue-select-2021?wid=5120&hei=2880&fmt=p-jpg",
#             "macbook air m2": "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/macbook-air-midnight-select-20220606?wid=904&hei=840&fmt=jpeg",
#             "macbook pro 14-inch": "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/macbook-pro-14-202301?wid=904&hei=840&fmt=jpeg",
#             "apple airpods pro (2nd gen)": "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/airpods-pro-2-hero-select-202209?wid=5120&hei=2880&fmt=p-jpg",
#             "apple airpods 3rd gen": "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/airpods-3rd-gen-hero-select-202203?wid=5120&hei=2880&fmt=p-jpg",
            
#             # Samsung Products
#             "samsung galaxy s23 ultra": "https://images.samsung.com/is/image/samsung/p6pim/in/2302/gallery/in-galaxy-s23-s918-sm-s918bzkdins-thumb-534866517",
#             "samsung galaxy z flip5": "https://images.samsung.com/is/image/samsung/p6pim/in/2307/gallery/in-galaxy-z-flip5-f731-471938-sm-f731blgains-thumb-537037635",
#             "samsung 55 inch 4k smart tv": "https://images.samsung.com/is/image/samsung/p6pim/in/ue55cu8570uxxl/gallery/in-uhd-4k-tv-ue55cu8570uxxl-536883917",
#             "samsung 65 inch qled tv": "https://images.samsung.com/is/image/samsung/p6pim/in/qa65q80cakxxl/gallery/in-qled-4k-tv-qa65q80cakxxl-534532866",
            
#             # OnePlus Products
#             "oneplus 11": "https://oasis.opstatics.com/content/dam/oasis/page/2023/na/2-21/in/11r/product-image/black.png",
#             "oneplus nord 3": "https://oasis.opstatics.com/content/dam/oasis/page/2023/nord-3/in/gallery/misty-green-1.png",
#             "oneplus tv 55 inch": "https://oasis.opstatics.com/content/dam/oasis/product/2020/tv/y-series/55-inch/na/gallery/black-1.png",
#             "oneplus tv 43 inch": "https://oasis.opstatics.com/content/dam/oasis/product/2020/tv/y-series/43-inch/na/gallery/black-1.png",
            
#             # Google Products
#             "google pixel 8 pro": "https://store.google.com/intl/en/in/category/phones?hl=en-IN&pli=1",
#             "google pixel 7a": "https://store.google.com/intl/en/in/category/phones?hl=en-IN",
            
#             # Xiaomi Products
#             "xiaomi 13 pro": "https://i01.appmifile.com/webfile/globalimg/in/cms/8B48E7A3-9F71-9A6E-3A5C-7A6A3C6A3C6A.jpg",
#             "redmi note 13 pro": "https://i01.appmifile.com/webfile/globalimg/in/cms/9916A7A3-9F71-9A6E-3A5C-7A6A3C6A3C6A.jpg",
#             "mi tv 5x 55 inch": "https://i01.appmifile.com/webfile/globalimg/in/cms/7A3C6A3C-9F71-9A6E-3A5C-7A6A3C6A3C6A.jpg",
#             "mi tv 4a 32 inch": "https://i01.appmifile.com/webfile/globalimg/in/cms/7A3C6A3C-9F71-9A6E-3A5C-7A6A3C6A3C6A.jpg",
            
#             # Sony Products
#             "sony wh-1000xm5": "https://www.sony.co.in/image/5a6b6e6c8dfd2d6a6e6c8dfd2d6a6e6c?fmt=pjpeg&wid=330&bgcolor=FFFFFF&bgc=FFFFFF",
#             "sony wh-ch720n": "https://www.sony.co.in/image/5a6b6e6c8dfd2d6a6e6c8dfd2d6a6e6c?fmt=pjpeg&wid=330&bgcolor=FFFFFF&bgc=FFFFFF",
#             "sony bravia 55 inch 4k": "https://www.sony.co.in/image/5a6b6e6c8dfd2d6a6e6c8dfd2d6a6e6c?fmt=pjpeg&wid=330&bgcolor=FFFFFF&bgc=FFFFFF",
#             "sony bravia 65 inch": "https://www.sony.co.in/image/5a6b6e6c8dfd2d6a6e6c8dfd2d6a6e6c?fmt=pjpeg&wid=330&bgcolor=FFFFFF&bgc=FFFFFF",
            
#             # Bose Products
#             "bose quietcomfort ultra": "https://assets.bose.com/content/dam/cloudassets/Bose_DAM/Web/consumer_electronics/global/products/headphones/qc_ultra_headphones/product_silo_images/qc_ultra_headphones_black_ec_1.psd/jcr:content/renditions/cq5dam.web.1280.1280.png",
#             "bose quietcomfort 45": "https://assets.bose.com/content/dam/cloudassets/Bose_DAM/Web/consumer_electronics/global/products/headphones/qc45/product_silo_images/qc45_black_ec_01.psd/jcr:content/renditions/cq5dam.web.1280.1280.png",
            
#             # Dell Products
#             "dell xps 13": "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/notebooks/xps-notebooks/xps-13-9320/media-gallery/notebook-xps-13-9320-t-black-gallery-1.psd?fmt=pjpg&pscan=auto&scl=1&wid=3337&hei=2417&qlt=100,0&resMode=sharp2&size=3337,2417",
#             "dell inspiron 15": "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/notebooks/inspiron-notebooks/15-3520/media-gallery/black/notebook-inspiron-15-3520-black-gallery-1.psd?fmt=pjpg&pscan=auto&scl=1&wid=3337&hei=2417&qlt=100,0&resMode=sharp2&size=3337,2417",
            
#             # HP Products
#             "hp pavilion": "https://ssl-product-images.www8-hp.com/digmedialib/prodimg/lowres/c08186650.png",
#             "hp victus gaming": "https://ssl-product-images.www8-hp.com/digmedialib/prodimg/lowres/c08198051.png",
            
#             # Lenovo Products
#             "lenovo thinkpad": "https://www.lenovo.com/medias/lenovo-laptop-thinkpad-x1-carbon-gen-11-14-intel-subseries-hero.png?context=bWFzdGVyfHJvb3R8MTQzNTU4fGltYWdlL3BuZ3xoYzYvaDgxLzE0MjYwNDY2MjA3MTY2LnBuZ3w0Y2Q4MTE3ZjYwYjQ4YjE3YzIxY2Q5ZTM2YzQ5ZTM4Y2U3YjE0YzQ0NzUxYzA4YzQ2Y2Y0YzYwYzQ4YjI4",
#             "lenovo ideapad": "https://www.lenovo.com/medias/lenovo-laptops-ideapad-3-15-intel-hero.png?context=bWFzdGVyfHJvb3R8MTQxNDM0fGltYWdlL3BuZ3xoYjYvaDc5LzE0MTQ1MTU0MzQzNTgyLnBuZ3w1YzE1YzA0YjUyYjQ3YzQ0YzQ5YzU4Y2I3Y2U4Y2Q3Y2Y4Y2Y0YzQ0YzQ0YzQ0YzQ0YzQ0YzQ0YzQ0",
            
#             # Asus Products
#             "asus zenbook": "https://dlcdnwebimgs.asus.com/gain/4A2C3190-7F3B-4F3D-9A9B-9A9B9A9B9A9B",
#             "asus tuf gaming": "https://dlcdnwebimgs.asus.com/gain/4A2C3190-7F3B-4F3D-9A9B-9A9B9A9B9A9B",
            
#             # JBL Products
#             "jbl wave beam": "https://www.jbl.com.in/on/demandware.static/-/Sites-masterCatalog_Harman/default/dw9a9b9a9b/images/jbl/WAVE_BEAM_BLK_001.png",
#             "jbl tune 770nc": "https://www.jbl.com.in/on/demandware.static/-/Sites-masterCatalog_Harman/default/dw9a9b9a9b/images/jbl/TUNE_770NC_BLK_001.png",
            
#             # Sennheiser Products
#             "sennheiser hd 450bt": "https://en-de.sennheiser.com/global-downloads/product/8454/image/zoom/zoom_8454_1.png",
#             "sennheiser accentum": "https://en-de.sennheiser.com/global-downloads/product/9534/image/zoom/zoom_9534_1.png",
            
#             # LG Products
#             "lg 55 inch oled tv": "https://www.lg.com/in/images/tv/md07565088/gallery/OLED55C3PSA_350_DZ_01.jpg",
#             "lg 43 inch smart tv": "https://www.lg.com/in/images/tv/md07565088/gallery/OLED55C3PSA_350_DZ_01.jpg",
            
#             # Vivo Products
#             "vivo v29": "https://www.vivo.com/in/products/v29",
            
#             # Oppo Products
#             "oppo reno 10": "https://www.oppo.com/in/phones/reno10/",
#         }
        
#         # Try exact product name match first
#         for key, url in image_mapping.items():
#             if key in product_lower:
#                 return url
        
#         # Try brand + category match
#         brand_category_key = f"{brand_lower} {category}"
#         for key, url in image_mapping.items():
#             if brand_lower in key and category in key:
#                 return url
        
#         # Try brand match
#         for key, url in image_mapping.items():
#             if brand_lower in key:
#                 return url
        
#         # Fallback to high-quality Unsplash images by category
#         category_fallbacks = {
#             "smartphone": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=300&fit=crop",
#             "laptop": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
#             "headphone": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
#             "tv": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop"
#         }
        
#         return category_fallbacks.get(category, "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=300&h=300&fit=crop")

#     def create_sample_dataset(self):
#         """Create a realistic sample dataset with Indian prices"""
#         os.makedirs("data", exist_ok=True)
        
#         # Sample products with realistic Indian e-commerce data
#         sample_products = [
#             # Smartphones
#             {"name": "iPhone 15 Pro", "category": "smartphone", "brand": "Apple", "base_price": 134900},
#             {"name": "iPhone 15", "category": "smartphone", "brand": "Apple", "base_price": 79900},
#             {"name": "Samsung Galaxy S23 Ultra", "category": "smartphone", "brand": "Samsung", "base_price": 124999},
#             {"name": "Samsung Galaxy Z Flip5", "category": "smartphone", "brand": "Samsung", "base_price": 99999},
#             {"name": "OnePlus 11", "category": "smartphone", "brand": "OnePlus", "base_price": 56999},
#             {"name": "OnePlus Nord 3", "category": "smartphone", "brand": "OnePlus", "base_price": 33999},
#             {"name": "Google Pixel 8 Pro", "category": "smartphone", "brand": "Google", "base_price": 106999},
#             {"name": "Google Pixel 7a", "category": "smartphone", "brand": "Google", "base_price": 43999},
#             {"name": "Xiaomi 13 Pro", "category": "smartphone", "brand": "Xiaomi", "base_price": 79999},
#             {"name": "Redmi Note 13 Pro", "category": "smartphone", "brand": "Xiaomi", "base_price": 25999},
#             {"name": "Vivo V29", "category": "smartphone", "brand": "Vivo", "base_price": 33990},
#             {"name": "Oppo Reno 10", "category": "smartphone", "brand": "Oppo", "base_price": 32999},
            
#             # Laptops
#             {"name": "MacBook Air M2", "category": "laptop", "brand": "Apple", "base_price": 114900},
#             {"name": "MacBook Pro 14-inch", "category": "laptop", "brand": "Apple", "base_price": 199900},
#             {"name": "Dell XPS 13", "category": "laptop", "brand": "Dell", "base_price": 124990},
#             {"name": "Dell Inspiron 15", "category": "laptop", "brand": "Dell", "base_price": 54990},
#             {"name": "HP Pavilion", "category": "laptop", "brand": "HP", "base_price": 65990},
#             {"name": "HP Victus Gaming", "category": "laptop", "brand": "HP", "base_price": 74990},
#             {"name": "Lenovo ThinkPad", "category": "laptop", "brand": "Lenovo", "base_price": 84900},
#             {"name": "Lenovo IdeaPad", "category": "laptop", "brand": "Lenovo", "base_price": 42990},
#             {"name": "Asus Zenbook", "category": "laptop", "brand": "Asus", "base_price": 89900},
#             {"name": "Asus TUF Gaming", "category": "laptop", "brand": "Asus", "base_price": 69990},
            
#             # Headphones
#             {"name": "Sony WH-1000XM5", "category": "headphone", "brand": "Sony", "base_price": 29990},
#             {"name": "Sony WH-CH720N", "category": "headphone", "brand": "Sony", "base_price": 11990},
#             {"name": "Bose QuietComfort Ultra", "category": "headphone", "brand": "Bose", "base_price": 35900},
#             {"name": "Bose QuietComfort 45", "category": "headphone", "brand": "Bose", "base_price": 28900},
#             {"name": "Apple AirPods Pro (2nd Gen)", "category": "headphone", "brand": "Apple", "base_price": 24900},
#             {"name": "Apple AirPods 3rd Gen", "category": "headphone", "brand": "Apple", "base_price": 19900},
#             {"name": "JBL Wave Beam", "category": "headphone", "brand": "JBL", "base_price": 5990},
#             {"name": "JBL Tune 770NC", "category": "headphone", "brand": "JBL", "base_price": 7990},
#             {"name": "Sennheiser HD 450BT", "category": "headphone", "brand": "Sennheiser", "base_price": 12990},
#             {"name": "Sennheiser Accentum", "category": "headphone", "brand": "Sennheiser", "base_price": 14990},
            
#             # TVs
#             {"name": "Samsung 55 inch 4K Smart TV", "category": "tv", "brand": "Samsung", "base_price": 54900},
#             {"name": "Samsung 65 inch QLED TV", "category": "tv", "brand": "Samsung", "base_price": 124999},
#             {"name": "LG 55 inch OLED TV", "category": "tv", "brand": "LG", "base_price": 89900},
#             {"name": "LG 43 inch Smart TV", "category": "tv", "brand": "LG", "base_price": 32900},
#             {"name": "Sony Bravia 55 inch 4K", "category": "tv", "brand": "Sony", "base_price": 74900},
#             {"name": "Sony Bravia 65 inch", "category": "tv", "brand": "Sony", "base_price": 104999},
#             {"name": "Mi TV 5X 55 inch", "category": "tv", "brand": "Xiaomi", "base_price": 41999},
#             {"name": "Mi TV 4A 32 inch", "category": "tv", "brand": "Xiaomi", "base_price": 13999},
#             {"name": "OnePlus TV 55 inch", "category": "tv", "brand": "OnePlus", "base_price": 39999},
#             {"name": "OnePlus TV 43 inch", "category": "tv", "brand": "OnePlus", "base_price": 26999},
#         ]
        
#         all_products = []
#         product_id = 1
        
#         platforms = ["Amazon", "Flipkart", "Reliance Digital", "Croma", "Vijay Sales"]
        
#         for product in sample_products:
#             for platform in platforms:
#                 # Create realistic price variations for each platform
#                 price_multiplier = random.uniform(0.85, 1.15)  # 85% to 115% of base price
#                 current_price = int(product["base_price"] * price_multiplier)
                
#                 # Add discounts (60% chance)
#                 original_price = current_price
#                 if random.random() > 0.4:
#                     discount_multiplier = random.uniform(1.1, 1.4)  # 10% to 40% discount
#                     original_price = int(current_price * discount_multiplier)
                
#                 # Realistic ratings and reviews
#                 rating = round(random.uniform(3.8, 4.8), 1)
#                 reviews = random.randint(500, 20000)
                
#                 # Delivery times based on platform
#                 delivery_times = {
#                     "Amazon": ["1-2 days", "Tomorrow", "2 days"],
#                     "Flipkart": ["2-3 days", "3-4 days"],
#                     "Reliance Digital": ["3-5 days", "1 week"],
#                     "Croma": ["2-4 days", "3-5 days"],
#                     "Vijay Sales": ["3-6 days", "1 week"]
#                 }
                
#                 all_products.append({
#                     "product_id": product_id,
#                     "product_name": product["name"],
#                     "category": product["category"],
#                     "brand": product["brand"],
#                     "price": current_price,
#                     "original_price": original_price,
#                     "rating": rating,
#                     "reviews": reviews,
#                     "platform": platform,
#                     "in_stock": random.choice([True, True, True, False]),  # 75% in stock
#                     "delivery_time": random.choice(delivery_times[platform]),
#                     "warranty": random.choice(["1 Year", "2 Years", "No Warranty", "Brand Warranty"])
#                 })
#                 product_id += 1
        
#         df = pd.DataFrame(all_products)
        
#         # Add URLs and REAL product images
#         df['url'] = 'https://example.com/product/' + df['product_name'].str.replace(' ', '-') + '-' + df['platform'].str.replace(' ', '')
        
#         # Use realistic product images instead of random picsum
#         df['image_url'] = df.apply(lambda row: self.get_realistic_product_image(
#             row['product_name'], row['brand'], row['category']
#         ), axis=1)
        
#         df.to_csv(self.dataset_path, index=False)
#         print(f"✅ Created sample dataset with {len(df)} products across {len(platforms)} platforms!")
#         print("🖼️  Real product images have been added!")
    
#     def search_products(self, query):
#         """Search products in dataset"""
#         if not query:
#             return [], "dataset"
        
#         query_lower = query.lower().strip()
        
#         # Search in product names, categories, and brands
#         mask = (
#             self.df['product_name'].str.lower().str.contains(query_lower, na=False) |
#             self.df['category'].str.lower().str.contains(query_lower, na=False) |
#             self.df['brand'].str.lower().str.contains(query_lower, na=False)
#         )
        
#         results = self.df[mask]
        
#         if len(results) == 0:
#             return [], "dataset"
        
#         products = []
#         for _, row in results.iterrows():
#             discount = 0
#             if row['original_price'] > row['price']:
#                 discount = int(((row['original_price'] - row['price']) / row['original_price']) * 100)
            
#             products.append({
#                 'id': row['product_id'],
#                 'name': row['product_name'],
#                 'price': float(row['price']),
#                 'original_price': float(row['original_price']),
#                 'discount_percentage': discount,
#                 'rating': float(row['rating']),
#                 'review_count': int(row['reviews']),
#                 'platform': row['platform'],
#                 'url': row['url'],
#                 'image_url': row['image_url'],
#                 'in_stock': row['in_stock'],
#                 'delivery': row['delivery_time'],
#                 'category': row['category'],
#                 'brand': row['brand'],
#                 'warranty': row['warranty']
#             })
        
#         # Sort by price (lowest first)
#         products.sort(key=lambda x: x['price'])
        
#         return products, "dataset"
    
#     def get_product_categories(self):
#         """Get all available product categories"""
#         return self.df['category'].unique().tolist()
    
#     def get_popular_searches(self):
#         """Get popular search suggestions"""
#         return ["iPhone", "Samsung", "Laptop", "Headphones", "TV", "OnePlus", "MacBook"]



import pandas as pd
import os
import random
from datetime import datetime

class DatasetPriceManager:
    def __init__(self):
        self.dataset_path = "data/products_dataset.csv"
        self.load_dataset()
    
    def load_dataset(self):
        """Load or create sample dataset"""
        if not os.path.exists(self.dataset_path):
            self.create_sample_dataset()
        
        self.df = pd.read_csv(self.dataset_path)
        print("✅ Price comparison dataset loaded successfully!")
    
    def get_product_image(self, product_name, brand, category):
        """Get reliable product images from Unsplash"""
        
        # Unsplash image mapping with reliable URLs
        product_images = {
            # Smartphones
            "iPhone 15 Pro": "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=300&h=300&fit=crop",
            "iPhone 15": "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=300&h=300&fit=crop",
            "Samsung Galaxy S23 Ultra": "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=300&h=300&fit=crop",
            "Samsung Galaxy Z Flip5": "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=300&h=300&fit=crop",
            "OnePlus 11": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=300&fit=crop",
            "OnePlus Nord 3": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=300&fit=crop",
            "Google Pixel 8 Pro": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=300&fit=crop",
            "Google Pixel 7a": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=300&fit=crop",
            "Xiaomi 13 Pro": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=300&fit=crop",
            "Redmi Note 13 Pro": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=300&fit=crop",
            "Vivo V29": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=300&fit=crop",
            "Oppo Reno 10": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=300&fit=crop",
            
            # Laptops
            "MacBook Air M2": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
            "MacBook Pro 14-inch": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
            "Dell XPS 13": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
            "Dell Inspiron 15": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
            "HP Pavilion": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
            "HP Victus Gaming": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
            "Lenovo ThinkPad": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
            "Lenovo IdeaPad": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
            "Asus Zenbook": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
            "Asus TUF Gaming": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
            
            # Headphones
            "Sony WH-1000XM5": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
            "Sony WH-CH720N": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
            "Bose QuietComfort Ultra": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
            "Bose QuietComfort 45": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
            "Apple AirPods Pro (2nd Gen)": "https://images.unsplash.com/photo-1590658165737-15a047b8b5e3?w=300&h=300&fit=crop",
            "Apple AirPods 3rd Gen": "https://images.unsplash.com/photo-1590658165737-15a047b8b5e3?w=300&h=300&fit=crop",
            "JBL Wave Beam": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
            "JBL Tune 770NC": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
            "Sennheiser HD 450BT": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
            "Sennheiser Accentum": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
            
            # TVs
            "Samsung 55 inch 4K Smart TV": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop",
            "Samsung 65 inch QLED TV": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop",
            "LG 55 inch OLED TV": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop",
            "LG 43 inch Smart TV": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop",
            "Sony Bravia 55 inch 4K": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop",
            "Sony Bravia 65 inch": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop",
            "Mi TV 5X 55 inch": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop",
            "Mi TV 4A 32 inch": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop",
            "OnePlus TV 55 inch": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop",
            "OnePlus TV 43 inch": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop",
        }
        
        # Return the specific product image or a generic category image
        return product_images.get(product_name, self.get_generic_image(category))
    
    def get_generic_image(self, category):
        """Get generic image based on category"""
        category_images = {
            "smartphone": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=300&fit=crop",
            "laptop": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
            "headphone": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
            "tv": "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop"
        }
        return category_images.get(category, "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=300&h=300&fit=crop")

    def create_sample_dataset(self):
        """Create a realistic sample dataset with Indian prices"""
        os.makedirs("data", exist_ok=True)
        
        # Sample products with realistic Indian e-commerce data
        sample_products = [
            # Smartphones
            {"name": "iPhone 15 Pro", "category": "smartphone", "brand": "Apple", "base_price": 134900},
            {"name": "iPhone 15", "category": "smartphone", "brand": "Apple", "base_price": 79900},
            {"name": "Samsung Galaxy S23 Ultra", "category": "smartphone", "brand": "Samsung", "base_price": 124999},
            {"name": "Samsung Galaxy Z Flip5", "category": "smartphone", "brand": "Samsung", "base_price": 99999},
            {"name": "OnePlus 11", "category": "smartphone", "brand": "OnePlus", "base_price": 56999},
            {"name": "OnePlus Nord 3", "category": "smartphone", "brand": "OnePlus", "base_price": 33999},
            {"name": "Google Pixel 8 Pro", "category": "smartphone", "brand": "Google", "base_price": 106999},
            {"name": "Google Pixel 7a", "category": "smartphone", "brand": "Google", "base_price": 43999},
            {"name": "Xiaomi 13 Pro", "category": "smartphone", "brand": "Xiaomi", "base_price": 79999},
            {"name": "Redmi Note 13 Pro", "category": "smartphone", "brand": "Xiaomi", "base_price": 25999},
            {"name": "Vivo V29", "category": "smartphone", "brand": "Vivo", "base_price": 33990},
            {"name": "Oppo Reno 10", "category": "smartphone", "brand": "Oppo", "base_price": 32999},
            
            # Laptops
            {"name": "MacBook Air M2", "category": "laptop", "brand": "Apple", "base_price": 114900},
            {"name": "MacBook Pro 14-inch", "category": "laptop", "brand": "Apple", "base_price": 199900},
            {"name": "Dell XPS 13", "category": "laptop", "brand": "Dell", "base_price": 124990},
            {"name": "Dell Inspiron 15", "category": "laptop", "brand": "Dell", "base_price": 54990},
            {"name": "HP Pavilion", "category": "laptop", "brand": "HP", "base_price": 65990},
            {"name": "HP Victus Gaming", "category": "laptop", "brand": "HP", "base_price": 74990},
            {"name": "Lenovo ThinkPad", "category": "laptop", "brand": "Lenovo", "base_price": 84900},
            {"name": "Lenovo IdeaPad", "category": "laptop", "brand": "Lenovo", "base_price": 42990},
            {"name": "Asus Zenbook", "category": "laptop", "brand": "Asus", "base_price": 89900},
            {"name": "Asus TUF Gaming", "category": "laptop", "brand": "Asus", "base_price": 69990},
            
            # Headphones
            {"name": "Sony WH-1000XM5", "category": "headphone", "brand": "Sony", "base_price": 29990},
            {"name": "Sony WH-CH720N", "category": "headphone", "brand": "Sony", "base_price": 11990},
            {"name": "Bose QuietComfort Ultra", "category": "headphone", "brand": "Bose", "base_price": 35900},
            {"name": "Bose QuietComfort 45", "category": "headphone", "brand": "Bose", "base_price": 28900},
            {"name": "Apple AirPods Pro (2nd Gen)", "category": "headphone", "brand": "Apple", "base_price": 24900},
            {"name": "Apple AirPods 3rd Gen", "category": "headphone", "brand": "Apple", "base_price": 19900},
            {"name": "JBL Wave Beam", "category": "headphone", "brand": "JBL", "base_price": 5990},
            {"name": "JBL Tune 770NC", "category": "headphone", "brand": "JBL", "base_price": 7990},
            {"name": "Sennheiser HD 450BT", "category": "headphone", "brand": "Sennheiser", "base_price": 12990},
            {"name": "Sennheiser Accentum", "category": "headphone", "brand": "Sennheiser", "base_price": 14990},
            
            # TVs
            {"name": "Samsung 55 inch 4K Smart TV", "category": "tv", "brand": "Samsung", "base_price": 54900},
            {"name": "Samsung 65 inch QLED TV", "category": "tv", "brand": "Samsung", "base_price": 124999},
            {"name": "LG 55 inch OLED TV", "category": "tv", "brand": "LG", "base_price": 89900},
            {"name": "LG 43 inch Smart TV", "category": "tv", "brand": "LG", "base_price": 32900},
            {"name": "Sony Bravia 55 inch 4K", "category": "tv", "brand": "Sony", "base_price": 74900},
            {"name": "Sony Bravia 65 inch", "category": "tv", "brand": "Sony", "base_price": 104999},
            {"name": "Mi TV 5X 55 inch", "category": "tv", "brand": "Xiaomi", "base_price": 41999},
            {"name": "Mi TV 4A 32 inch", "category": "tv", "brand": "Xiaomi", "base_price": 13999},
            {"name": "OnePlus TV 55 inch", "category": "tv", "brand": "OnePlus", "base_price": 39999},
            {"name": "OnePlus TV 43 inch", "category": "tv", "brand": "OnePlus", "base_price": 26999},
        ]
        
        all_products = []
        product_id = 1
        
        platforms = ["Amazon", "Flipkart", "Reliance Digital", "Croma", "Vijay Sales"]
        
        for product in sample_products:
            # Get ONE consistent image for this product
            product_image = self.get_product_image(product["name"], product["brand"], product["category"])
            
            for platform in platforms:
                # Create realistic price variations for each platform
                price_multiplier = random.uniform(0.85, 1.15)  # 85% to 115% of base price
                current_price = int(product["base_price"] * price_multiplier)
                
                # Add discounts (60% chance)
                original_price = current_price
                if random.random() > 0.4:
                    discount_multiplier = random.uniform(1.1, 1.4)  # 10% to 40% discount
                    original_price = int(current_price * discount_multiplier)
                
                # Realistic ratings and reviews
                rating = round(random.uniform(3.8, 4.8), 1)
                reviews = random.randint(500, 20000)
                
                # Delivery times based on platform
                delivery_times = {
                    "Amazon": ["1-2 days", "Tomorrow", "2 days"],
                    "Flipkart": ["2-3 days", "3-4 days"],
                    "Reliance Digital": ["3-5 days", "1 week"],
                    "Croma": ["2-4 days", "3-5 days"],
                    "Vijay Sales": ["3-6 days", "1 week"]
                }
                
                all_products.append({
                    "product_id": product_id,
                    "product_name": product["name"],
                    "category": product["category"],
                    "brand": product["brand"],
                    "price": current_price,
                    "original_price": original_price,
                    "rating": rating,
                    "reviews": reviews,
                    "platform": platform,
                    "in_stock": random.choice([True, True, True, False]),  # 75% in stock
                    "delivery_time": random.choice(delivery_times[platform]),
                    "warranty": random.choice(["1 Year", "2 Years", "No Warranty", "Brand Warranty"]),
                    "image_url": product_image  # Same image for all platforms
                })
                product_id += 1
        
        df = pd.DataFrame(all_products)
        
        # Add URLs
        df['url'] = 'https://example.com/product/' + df['product_name'].str.replace(' ', '-') + '-' + df['platform'].str.replace(' ', '')
        
        df.to_csv(self.dataset_path, index=False)
        print(f"✅ Created sample dataset with {len(df)} products across {len(platforms)} platforms!")
        print("🖼️  Real product images from Unsplash have been added!")
    
    def search_products(self, query):
        """Search products in dataset"""
        if not query:
            return [], "dataset"
        
        query_lower = query.lower().strip()
        
        # Search in product names, categories, and brands
        mask = (
            self.df['product_name'].str.lower().str.contains(query_lower, na=False) |
            self.df['category'].str.lower().str.contains(query_lower, na=False) |
            self.df['brand'].str.lower().str.contains(query_lower, na=False)
        )
        
        results = self.df[mask]
        
        if len(results) == 0:
            return [], "dataset"
        
        products = []
        for _, row in results.iterrows():
            discount = 0
            if row['original_price'] > row['price']:
                discount = int(((row['original_price'] - row['price']) / row['original_price']) * 100)
            
            products.append({
                'id': row['product_id'],
                'name': row['product_name'],
                'price': float(row['price']),
                'original_price': float(row['original_price']),
                'discount_percentage': discount,
                'rating': float(row['rating']),
                'review_count': int(row['reviews']),
                'platform': row['platform'],
                'url': row['url'],
                'image_url': row['image_url'],
                'in_stock': row['in_stock'],
                'delivery': row['delivery_time'],
                'category': row['category'],
                'brand': row['brand'],
                'warranty': row['warranty']
            })
        
        # Sort by price (lowest first)
        products.sort(key=lambda x: x['price'])
        
        return products, "dataset"
    
    def get_product_categories(self):
        """Get all available product categories"""
        return self.df['category'].unique().tolist()
    
    def get_popular_searches(self):
        """Get popular search suggestions"""
        return ["iPhone", "Samsung", "Laptop", "Headphones", "TV", "OnePlus", "MacBook"]