import sqlite3
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
import time

class LargeRefundAbuseDetector:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.abuse_thresholds = {
            'return_frequency': 4,  # Adjusted for larger dataset
            'return_rate': 0.35,    # Adjusted threshold
            'high_value_returns': 3,
            'short_ownership': 5,
            'recent_activity': 7    # Returns in last 7 days
        }
    
    def batch_process_customers(self, batch_size=100):
        """Process customers in batches to handle large datasets"""
        conn = sqlite3.connect(self.db_path)
        
        # Get total customer count
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM customers")
        total_customers = cursor.fetchone()[0]
        
        flagged_customers = []
        
        # Process in batches
        for offset in range(0, total_customers, batch_size):
            print(f"Processing batch {offset//batch_size + 1}/{(total_customers + batch_size - 1)//batch_size}")
            
            # Get batch of customers with returns
            batch_query = """
            SELECT DISTINCT c.id, c.email, c.name
            FROM customers c
            JOIN returns r ON c.id = r.customer_id
            LIMIT ? OFFSET ?
            """
            
            batch_customers = conn.execute(batch_query, (batch_size, offset)).fetchall()
            
            for customer_id, email, name in batch_customers:
                risk_score = self.calculate_customer_risk_score(customer_id)
                
                if risk_score >= 40:  # Lower threshold for larger dataset
                    reasons = self.get_abuse_reasons(customer_id)
                    severity = 'high' if risk_score >= 70 else 'medium'
                    
                    self.flag_suspicious_customer(customer_id, ' | '.join(reasons), severity)
                    flagged_customers.append({
                        'customer_id': customer_id,
                        'email': email,
                        'name': name,
                        'risk_score': risk_score,
                        'reasons': reasons,
                        'severity': severity
                    })
        
        conn.close()
        return flagged_customers
    
    def calculate_customer_risk_score(self, customer_id: int) -> int:
        """Optimized risk calculation for large datasets"""
        risk_score = 0
        
        # Single query to get multiple metrics
        conn = sqlite3.connect(self.db_path)
        
        metrics_query = """
        WITH customer_metrics AS (
            SELECT 
                c.id,
                COUNT(DISTINCT o.id) as total_orders,
                COUNT(DISTINCT r.id) as total_returns,
                COUNT(DISTINCT CASE WHEN r.return_date >= datetime('now', '-30 days') THEN r.id END) as recent_returns,
                COUNT(DISTINCT CASE WHEN r.refund_amount > 100 THEN r.id END) as high_value_returns,
                COUNT(DISTINCT CASE WHEN julianday(r.return_date) - julianday(o.order_date) <= 7 THEN r.id END) as quick_returns
            FROM customers c
            LEFT JOIN orders o ON c.id = o.customer_id
            LEFT JOIN returns r ON o.id = r.order_id
            WHERE c.id = ?
            GROUP BY c.id
        )
        SELECT * FROM customer_metrics
        """
        
        result = conn.execute(metrics_query, (customer_id,)).fetchone()
        conn.close()
        
        if not result:
            return 0
        
        _, total_orders, total_returns, recent_returns, high_value_returns, quick_returns = result
        
        # 1. Return frequency (max 25 points)
        if recent_returns >= self.abuse_thresholds['return_frequency']:
            risk_score += min(25, recent_returns * 6)
        
        # 2. Return rate (max 30 points)
        if total_orders > 0:
            return_rate = total_returns / total_orders
            if return_rate > self.abuse_thresholds['return_rate']:
                risk_score += min(30, int(return_rate * 100))
        
        # 3. High-value returns (max 20 points)
        if high_value_returns >= self.abuse_thresholds['high_value_returns']:
            risk_score += min(20, high_value_returns * 7)
        
        # 4. Quick returns (max 15 points)
        risk_score += min(15, quick_returns * 3)
        
        # 5. Pattern detection (max 10 points)
        if self.has_suspicious_patterns(customer_id):
            risk_score += 10
        
        return min(risk_score, 100)
    
    def has_suspicious_patterns(self, customer_id: int) -> bool:
        """Check for suspicious patterns efficiently"""
        conn = sqlite3.connect(self.db_path)
        
        # Check for same-day returns pattern
        pattern_query = """
        SELECT COUNT(*) as pattern_count
        FROM (
            SELECT DATE(return_date) as return_day, COUNT(*) as returns_per_day
            FROM returns 
            WHERE customer_id = ?
            GROUP BY DATE(return_date)
            HAVING COUNT(*) >= 2
        ) daily_returns
        """
        
        result = conn.execute(pattern_query, (customer_id,)).fetchone()
        conn.close()
        
        return result[0] > 0 if result else False
    
    def get_abuse_reasons(self, customer_id: int) -> List[str]:
        """Get reasons for flagging"""
        reasons = []
        conn = sqlite3.connect(self.db_path)
        
        metrics_query = """
        SELECT 
            COUNT(DISTINCT o.id) as total_orders,
            COUNT(DISTINCT r.id) as total_returns,
            COUNT(DISTINCT CASE WHEN r.return_date >= datetime('now', '-30 days') THEN r.id END) as recent_returns
        FROM customers c
        LEFT JOIN orders o ON c.id = o.customer_id
        LEFT JOIN returns r ON o.id = r.order_id
        WHERE c.id = ?
        GROUP BY c.id
        """
        
        result = conn.execute(metrics_query, (customer_id,)).fetchone()
        conn.close()
        
        if not result:
            return reasons
        
        total_orders, total_returns, recent_returns = result
        
        if recent_returns >= self.abuse_thresholds['return_frequency']:
            reasons.append(f"High return frequency: {recent_returns} returns in 30 days")
        
        if total_orders > 0:
            return_rate = total_returns / total_orders
            if return_rate > self.abuse_thresholds['return_rate']:
                reasons.append(f"High return rate: {return_rate:.1%}")
        
        return reasons
    
    def flag_suspicious_customer(self, customer_id: int, reason: str, severity: str):
        """Flag suspicious customer"""
        conn = sqlite3.connect(self.db_path)
        
        # Remove existing active flags
        conn.execute("UPDATE abuse_flags SET is_active = FALSE WHERE customer_id = ?", (customer_id,))
        
        # Insert new flag
        conn.execute("""
        INSERT INTO abuse_flags (customer_id, flag_reason, severity, is_active)
        VALUES (?, ?, ?, TRUE)
        """, (customer_id, reason, severity))
        
        # Update customer risk score
        risk_score = self.calculate_customer_risk_score(customer_id)
        conn.execute("""
        UPDATE customers 
        SET risk_score = ?, is_flagged = TRUE 
        WHERE id = ?
        """, (risk_score, customer_id))
        
        conn.commit()
        conn.close()
    
    def scan_for_abuse(self, days: int = 90):
        """Main scanning function with progress tracking"""
        print(f"Starting abuse scan for last {days} days...")
        start_time = time.time()
        
        flagged_customers = self.batch_process_customers(batch_size=100)
        
        end_time = time.time()
        print(f"Scan completed in {end_time - start_time:.2f} seconds")
        print(f"Found {len(flagged_customers)} potentially suspicious customers")
        
        return flagged_customers

# Test with large dataset
if __name__ == "__main__":
    detector = LargeRefundAbuseDetector('large_refund_abuse.db')
    flagged = detector.scan_for_abuse(days=90)
    
    # Print top 10 highest risk customers
    print("\nTop 10 Highest Risk Customers:")
    print("=" * 80)
    for customer in sorted(flagged, key=lambda x: x['risk_score'], reverse=True)[:10]:
        print(f"Customer: {customer['name']} ({customer['email']})")
        print(f"Risk Score: {customer['risk_score']} | Severity: {customer['severity']}")
        print("Reasons:", ", ".join(customer['reasons']))
        print("-" * 80)