import sqlite3
from datetime import datetime

class PriceComparisonDB:
    def __init__(self, db_path='price_comparison.db'):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Products table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT,
            image_url TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Prices table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS prices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER,
            platform TEXT NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            original_price DECIMAL(10,2),
            availability TEXT,
            product_url TEXT,
            rating DECIMAL(3,2),
            review_count INTEGER,
            scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
        ''')
        
        # Favorites table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS favorites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_session TEXT NOT NULL,
            product_id INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
        ''')
        
        # Search history table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS search_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_session TEXT NOT NULL,
            query TEXT NOT NULL,
            results_count INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_product(self, name, category=None, image_url=None):
        """Add or get existing product"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if product exists
        cursor.execute('SELECT id FROM products WHERE name = ?', (name,))
        result = cursor.fetchone()
        
        if result:
            product_id = result[0]
        else:
            cursor.execute(
                'INSERT INTO products (name, category, image_url) VALUES (?, ?, ?)',
                (name, category, image_url)
            )
            product_id = cursor.lastrowid
        
        conn.commit()
        conn.close()
        return product_id
    
    def add_price(self, product_id, platform, price, original_price=None, 
                  availability="In Stock", product_url=None, rating=None, review_count=None):
        """Add price data for a product"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
        INSERT INTO prices (product_id, platform, price, original_price, 
                          availability, product_url, rating, review_count)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (product_id, platform, price, original_price, availability, 
              product_url, rating, review_count))
        
        conn.commit()
        conn.close()
    
    def add_to_favorites(self, user_session, product_id):
        """Add product to user's favorites"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if already in favorites
        cursor.execute(
            'SELECT id FROM favorites WHERE user_session = ? AND product_id = ?',
            (user_session, product_id)
        )
        
        if not cursor.fetchone():
            cursor.execute(
                'INSERT INTO favorites (user_session, product_id) VALUES (?, ?)',
                (user_session, product_id)
            )
        
        conn.commit()
        conn.close()
    
    def remove_from_favorites(self, user_session, product_id):
        """Remove product from user's favorites"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            'DELETE FROM favorites WHERE user_session = ? AND product_id = ?',
            (user_session, product_id)
        )
        
        conn.commit()
        conn.close()
    
    def get_favorites(self, user_session):
        """Get user's favorite products with latest prices"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query = '''
        SELECT 
            p.id, p.name, p.category, p.image_url,
            f.created_at as favorited_at,
            GROUP_CONCAT(DISTINCT pr.platform) as platforms,
            MIN(pr.price) as best_price
        FROM favorites f
        JOIN products p ON f.product_id = p.id
        LEFT JOIN prices pr ON p.id = pr.product_id 
            AND pr.scraped_at = (
                SELECT MAX(scraped_at) 
                FROM prices 
                WHERE product_id = p.id AND platform = pr.platform
            )
        WHERE f.user_session = ?
        GROUP BY p.id
        ORDER BY f.created_at DESC
        '''
        
        cursor.execute(query, (user_session,))
        results = cursor.fetchall()
        conn.close()
        
        return [{
            'id': row[0],
            'name': row[1],
            'category': row[2],
            'image_url': row[3],
            'favorited_at': row[4],
            'platforms': row[5].split(',') if row[5] else [],
            'best_price': row[6]
        } for row in results]
    
    def get_product_prices(self, product_id):
        """Get all prices for a product across platforms"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query = '''
        SELECT platform, price, original_price, availability, 
               product_url, rating, review_count, scraped_at
        FROM prices
        WHERE product_id = ? 
        AND scraped_at = (
            SELECT MAX(scraped_at) 
            FROM prices p2 
            WHERE p2.product_id = prices.product_id 
            AND p2.platform = prices.platform
        )
        ORDER BY price ASC
        '''
        
        cursor.execute(query, (product_id,))
        results = cursor.fetchall()
        conn.close()
        
        return [{
            'platform': row[0],
            'price': row[1],
            'original_price': row[2],
            'availability': row[3],
            'product_url': row[4],
            'rating': row[5],
            'review_count': row[6],
            'scraped_at': row[7]
        } for row in results]