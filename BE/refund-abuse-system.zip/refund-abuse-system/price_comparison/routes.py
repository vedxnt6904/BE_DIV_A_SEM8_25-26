from flask import Blueprint, render_template, request, jsonify, session
import uuid
from .scraper import PriceScraper
from .models import PriceComparisonDB
import time

# Create Blueprint
price_bp = Blueprint('price_comparison', __name__, 
                    template_folder='templates',
                    static_folder='static')

# Initialize components
scraper = PriceScraper()
db = PriceComparisonDB()

@price_bp.before_request
def before_request():
    """Initialize user session for favorites"""
    if 'user_id' not in session:
        session['user_id'] = str(uuid.uuid4())

@price_bp.route('/price-comparison')
def price_comparison():
    """Main price comparison page"""
    return render_template('price_comparison.html')

@price_bp.route('/search-prices', methods=['POST'])
def search_prices():
    """Search prices across platforms"""
    try:
        query = request.form.get('query', '').strip()
        
        if not query:
            return jsonify({'error': 'Please enter a search query'}), 400
        
        # Search all platforms
        results = scraper.search_all_platforms(query)
        
        # Store results in database
        for product in results:
            product_id = db.add_product(
                name=product['name'],
                category=None,  # You can add category detection
                image_url=product['image_url']
            )
            
            db.add_price(
                product_id=product_id,
                platform=product['platform'],
                price=product['price'],
                original_price=product.get('original_price'),
                availability="In Stock",
                product_url=product['url'],
                rating=product.get('rating'),
                review_count=product.get('review_count')
            )
        
        return render_template('search_results.html', 
                             products=results, 
                             query=query,
                             results_count=len(results))
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@price_bp.route('/api/search')
def api_search():
    """API endpoint for search (for AJAX requests)"""
    try:
        query = request.args.get('q', '').strip()
        
        if not query:
            return jsonify({'error': 'Query parameter required'}), 400
        
        results = scraper.search_all_platforms(query)
        return jsonify({'results': results, 'query': query})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@price_bp.route('/add-favorite', methods=['POST'])
def add_favorite():
    """Add product to favorites"""
    try:
        product_name = request.form.get('product_name')
        user_session = session['user_id']
        
        # Get or create product
        product_id = db.add_product(name=product_name)
        
        # Add to favorites
        db.add_to_favorites(user_session, product_id)
        
        return jsonify({'success': True, 'message': 'Added to favorites'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@price_bp.route('/remove-favorite', methods=['POST'])
def remove_favorite():
    """Remove product from favorites"""
    try:
        product_name = request.form.get('product_name')
        user_session = session['user_id']
        
        # Get product ID
        conn = db._get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT id FROM products WHERE name = ?', (product_name,))
        result = cursor.fetchone()
        conn.close()
        
        if result:
            db.remove_from_favorites(user_session, result[0])
        
        return jsonify({'success': True, 'message': 'Removed from favorites'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@price_bp.route('/favorites')
def favorites():
    """View user's favorite products"""
    user_session = session['user_id']
    favorites = db.get_favorites(user_session)
    
    return render_template('favorites.html', favorites=favorites)

@price_bp.route('/product-details/<int:product_id>')
def product_details(product_id):
    """Get detailed price history for a product"""
    prices = db.get_product_prices(product_id)
    
    # Get product info
    conn = db._get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT name, category, image_url FROM products WHERE id = ?', (product_id,))
    product_info = cursor.fetchone()
    conn.close()
    
    if product_info:
        return render_template('product_details.html',
                             product={
                                 'id': product_id,
                                 'name': product_info[0],
                                 'category': product_info[1],
                                 'image_url': product_info[2]
                             },
                             prices=prices)
    else:
        return "Product not found", 404