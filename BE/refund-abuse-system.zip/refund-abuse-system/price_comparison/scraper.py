import requests
from bs4 import BeautifulSoup
import time
import random
from fake_useragent import UserAgent
import json
import re

class PriceScraper:
    def __init__(self):
        self.ua = UserAgent()
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        })
    
    def get_headers(self):
        return {
            'User-Agent': self.ua.random,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        }
    
    def search_amazon(self, query):
        """Search Amazon for products"""
        try:
            url = f"https://www.amazon.in/s?k={query.replace(' ', '+')}"
            headers = self.get_headers()
            
            response = self.session.get(url, headers=headers, timeout=10)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            products = []
            items = soup.select('.s-result-item[data-component-type="s-search-result"]')
            
            for item in items[:5]:  # Limit to 5 results
                try:
                    # Product name
                    name_elem = item.select_one('h2 a span')
                    name = name_elem.text.strip() if name_elem else None
                    
                    # Price
                    price_elem = item.select_one('.a-price-whole')
                    price = float(price_elem.text.replace(',', '').strip()) if price_elem else None
                    
                    # Original price
                    original_price_elem = item.select_one('.a-price.a-text-price span')
                    original_price = float(original_price_elem.text.replace('₹', '').replace(',', '').strip()) if original_price_elem else None
                    
                    # Rating
                    rating_elem = item.select_one('.a-icon-alt')
                    rating = float(rating_elem.text.split()[0]) if rating_elem else None
                    
                    # Reviews count
                    reviews_elem = item.select_one('.a-size-base.s-underline-text')
                    review_count = int(reviews_elem.text.replace(',', '').strip()) if reviews_elem else 0
                    
                    # URL
                    link_elem = item.select_one('h2 a')
                    product_url = "https://www.amazon.in" + link_elem['href'] if link_elem else None
                    
                    # Image
                    image_elem = item.select_one('.s-image')
                    image_url = image_elem['src'] if image_elem else None
                    
                    if name and price:
                        products.append({
                            'name': name,
                            'price': price,
                            'original_price': original_price,
                            'rating': rating,
                            'review_count': review_count,
                            'url': product_url,
                            'image_url': image_url,
                            'platform': 'Amazon'
                        })
                except Exception as e:
                    continue
            
            return products
            
        except Exception as e:
            print(f"Amazon scraping error: {e}")
            return []
    
    def search_flipkart(self, query):
        """Search Flipkart for products"""
        try:
            url = f"https://www.flipkart.com/search?q={query.replace(' ', '%20')}"
            headers = self.get_headers()
            
            response = self.session.get(url, headers=headers, timeout=10)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            products = []
            items = soup.select('div[data-id]')
            
            for item in items[:5]:
                try:
                    # Product name
                    name_elem = item.select_one('a[title]')
                    name = name_elem['title'] if name_elem else None
                    
                    # Price
                    price_elem = item.select_one('div._30jeq3')
                    if price_elem:
                        price_text = price_elem.text.replace('₹', '').replace(',', '').strip()
                        price = float(price_text)
                    else:
                        price = None
                    
                    # Original price
                    original_price_elem = item.select_one('div._3I9_wc')
                    if original_price_elem:
                        original_price_text = original_price_elem.text.replace('₹', '').replace(',', '').strip()
                        original_price = float(original_price_text)
                    else:
                        original_price = None
                    
                    # Rating
                    rating_elem = item.select_one('div._3LWZlK')
                    rating = float(rating_elem.text) if rating_elem else None
                    
                    # Reviews count
                    reviews_elem = item.select_one('span._2_R_DZ')
                    review_count = 0
                    if reviews_elem:
                        review_text = reviews_elem.text
                        review_match = re.search(r'(\d+,?\d*)', review_text)
                        if review_match:
                            review_count = int(review_match.group(1).replace(',', ''))
                    
                    # URL
                    link_elem = item.select_one('a._1fQZEK')
                    product_url = "https://www.flipkart.com" + link_elem['href'] if link_elem else None
                    
                    # Image
                    image_elem = item.select_one('img._396cs4')
                    image_url = image_elem['src'] if image_elem else None
                    
                    if name and price:
                        products.append({
                            'name': name,
                            'price': price,
                            'original_price': original_price,
                            'rating': rating,
                            'review_count': review_count,
                            'url': product_url,
                            'image_url': image_url,
                            'platform': 'Flipkart'
                        })
                except Exception as e:
                    continue
            
            return products
            
        except Exception as e:
            print(f"Flipkart scraping error: {e}")
            return []
    
    def search_ebay(self, query):
        """Search eBay for products (mock data for demo)"""
        try:
            # Note: eBay requires more complex handling and may need Selenium
            # For demo purposes, returning mock data
            mock_products = [
                {
                    'name': f'{query} - Brand New',
                    'price': round(random.uniform(500, 5000), 2),
                    'original_price': None,
                    'rating': round(random.uniform(3.5, 5.0), 1),
                    'review_count': random.randint(10, 500),
                    'url': f'https://www.ebay.com/itm/{query.replace(" ", "-")}',
                    'image_url': 'https://via.placeholder.com/150',
                    'platform': 'eBay'
                }
                for _ in range(3)
            ]
            return mock_products
            
        except Exception as e:
            print(f"eBay scraping error: {e}")
            return []
    
    def search_myntra(self, query):
        """Search Myntra for fashion products"""
        try:
            url = f"https://www.myntra.com/{query.replace(' ', '-')}"
            headers = self.get_headers()
            
            # Myntra might block simple requests, so using mock data for demo
            mock_products = [
                {
                    'name': f'{query} - Fashion Item',
                    'price': round(random.uniform(299, 2999), 2),
                    'original_price': round(random.uniform(399, 3999), 2),
                    'rating': round(random.uniform(3.8, 4.9), 1),
                    'review_count': random.randint(50, 1000),
                    'url': f'https://www.myntra.com/{query.replace(" ", "-")}',
                    'image_url': 'https://via.placeholder.com/150',
                    'platform': 'Myntra'
                }
                for _ in range(2)
            ]
            return mock_products
            
        except Exception as e:
            print(f"Myntra scraping error: {e}")
            return []
    
    def search_all_platforms(self, query):
        """Search all platforms and return combined results"""
        print(f"Searching for: {query}")
        
        # Search all platforms
        amazon_results = self.search_amazon(query)
        flipkart_results = self.search_flipkart(query)
        ebay_results = self.search_ebay(query)
        myntra_results = self.search_myntra(query)
        
        # Combine all results
        all_results = amazon_results + flipkart_results + flipkart_results + ebay_results + myntra_results
        
        # Remove duplicates based on name and platform
        seen = set()
        unique_results = []
        
        for product in all_results:
            identifier = (product['name'], product['platform'])
            if identifier not in seen:
                seen.add(identifier)
                unique_results.append(product)
        
        # Sort by price
        unique_results.sort(key=lambda x: x['price'] if x['price'] else float('inf'))
        
        return unique_results