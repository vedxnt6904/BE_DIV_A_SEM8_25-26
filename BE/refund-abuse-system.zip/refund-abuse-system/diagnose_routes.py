from flask import Flask

app = Flask(__name__)
app.secret_key = 'test-secret-key'

try:
    from price_comparison.routes import price_bp
    app.register_blueprint(price_bp, url_prefix='/price-comparison')
    
    print("✅ Blueprint registered successfully!")
    print("\n📋 ALL REGISTERED ROUTES:")
    print("=" * 50)
    
    for rule in app.url_map.iter_rules():
        methods = ','.join(rule.methods)
        print(f"Route: {rule}")
        print(f"Methods: {methods}")
        print(f"Endpoint: {rule.endpoint}")
        print("-" * 30)
        
except Exception as e:
    print(f"❌ Error: {e}")