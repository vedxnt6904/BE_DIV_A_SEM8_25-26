from flask import Flask

app = Flask(__name__)
app.secret_key = 'test-key'

# Add the price comparison routes directly
@app.route('/price-comparison')
def price_comparison_main():
    return "Price Comparison Page - WORKS!"

@app.route('/price-comparison/search-prices', methods=['POST'])
def search_prices():
    return "Search Prices - WORKS!"

@app.route('/price-comparison/favorites')
def favorites():
    return "Favorites Page - WORKS!"

# Test the app
with app.test_client() as client:
    print("Testing routes...")
    
    # Test GET request to price-comparison
    response = client.get('/price-comparison')
    print(f"GET /price-comparison: {response.status_code} - {response.get_data(as_text=True)}")
    
    # Test GET request to favorites
    response = client.get('/price-comparison/favorites')
    print(f"GET /price-comparison/favorites: {response.status_code} - {response.get_data(as_text=True)}")
    
    print("\n✅ If you see 'WORKS!' above, the routes are configured correctly!")
    print("🔧 The issue might be with template rendering.")