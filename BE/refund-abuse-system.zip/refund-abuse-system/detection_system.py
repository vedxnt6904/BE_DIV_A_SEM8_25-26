import sqlite3
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
import json

class RefundAbuseDetector:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.abuse_thresholds = {
            'return_frequency': 3,
            'return_rate': 0.3,
            'high_value_returns': 2,
            'short_ownership': 7,
            'pattern_returns': 5
        }
    
    def calculate_customer_risk_score(self, customer_id: int) -> int:
        risk_score = 0
        customer_data = self.get_customer_return_data(customer_id)
        if not customer_data:
            return 0
        
        recent_returns = self.get_recent_returns_count(customer_id, 30)
        if recent_returns >= self.abuse_thresholds['return_frequency']:
            risk_score += min(30, recent_returns * 10)
        
        return_rate = self.get_return_rate(customer_id)
        if return_rate > self.abuse_thresholds['return_rate']:
            risk_score += min(25, int(return_rate * 100))
        
        return min(risk_score, 100)
    
    def get_customer_return_data(self, customer_id: int) -> Dict:
        conn = sqlite3.connect(self.db_path)
        query = """
        SELECT 
            c.id, c.email, c.name,
            COUNT(DISTINCT o.id) as total_orders,
            COUNT(DISTINCT r.id) as total_returns
        FROM customers c
        LEFT JOIN orders o ON c.id = o.customer_id
        LEFT JOIN returns r ON o.id = r.order_id
        WHERE c.id = ?
        GROUP BY c.id, c.email, c.name
        """
        df = pd.read_sql_query(query, conn, params=[customer_id])
        conn.close()
        return df.to_dict('records')[0] if not df.empty else {}
    
    def get_recent_returns_count(self, customer_id: int, days: int = 30) -> int:
        conn = sqlite3.connect(self.db_path)
        query = """
        SELECT COUNT(*) as return_count
        FROM returns 
        WHERE customer_id = ? 
        AND return_date >= datetime('now', ?)
        """
        result = conn.execute(query, (customer_id, f'-{days} days')).fetchone()
        conn.close()
        return result[0] if result else 0
    
    def get_return_rate(self, customer_id: int) -> float:
        conn = sqlite3.connect(self.db_path)
        query = """
        SELECT 
            COUNT(DISTINCT o.id) as total_orders,
            COUNT(DISTINCT r.id) as total_returns
        FROM customers c
        LEFT JOIN orders o ON c.id = o.customer_id
        LEFT JOIN returns r ON o.id = r.order_id
        WHERE c.id = ?
        """
        result = conn.execute(query, (customer_id,)).fetchone()
        conn.close()
        if result and result[0] > 0:
            return result[1] / result[0]
        return 0.0
    
    def scan_for_abuse(self, days: int = 90):
        conn = sqlite3.connect(self.db_path)
        query = """
        SELECT DISTINCT c.id, c.email, c.name
        FROM customers c
        JOIN returns r ON c.id = r.customer_id
        WHERE r.return_date >= datetime('now', ?)
        """
        customers = conn.execute(query, (f'-{days} days',)).fetchall()
        conn.close()
        
        flagged_customers = []
        for customer_id, email, name in customers:
            risk_score = self.calculate_customer_risk_score(customer_id)
            if risk_score >= 50:
                reasons = self.get_abuse_reasons(customer_id)
                severity = 'high' if risk_score >= 75 else 'medium'
                self.flag_suspicious_customer(customer_id, ' | '.join(reasons), severity)
                flagged_customers.append({
                    'customer_id': customer_id,
                    'email': email,
                    'name': name,
                    'risk_score': risk_score,
                    'reasons': reasons,
                    'severity': severity
                })
        return flagged_customers
    
    def get_abuse_reasons(self, customer_id: int) -> List[str]:
        reasons = []
        recent_returns = self.get_recent_returns_count(customer_id, 30)
        if recent_returns >= self.abuse_thresholds['return_frequency']:
            reasons.append(f"High return frequency: {recent_returns} returns in 30 days")
        
        return_rate = self.get_return_rate(customer_id)
        if return_rate > self.abuse_thresholds['return_rate']:
            reasons.append(f"High return rate: {return_rate:.1%}")
        
        return reasons
    
    def flag_suspicious_customer(self, customer_id: int, reason: str, severity: str):
        conn = sqlite3.connect(self.db_path)
        conn.execute("""
        INSERT INTO abuse_flags (customer_id, flag_reason, severity, is_active)
        VALUES (?, ?, ?, TRUE)
        """, (customer_id, reason, severity))
        
        risk_score = self.calculate_customer_risk_score(customer_id)
        conn.execute("""
        UPDATE customers 
        SET risk_score = ?, is_flagged = TRUE 
        WHERE id = ?
        """, (risk_score, customer_id))
        conn.commit()
        conn.close()

if __name__ == "__main__":
    detector = RefundAbuseDetector('refund_abuse.db')
    print("Scanning for refund abuse...")
    flagged_customers = detector.scan_for_abuse(days=90)
    print(f"\nFound {len(flagged_customers)} potentially suspicious customers:")
    for customer in flagged_customers:
        print(f"Customer: {customer['name']} ({customer['email']}) - Score: {customer['risk_score']}")