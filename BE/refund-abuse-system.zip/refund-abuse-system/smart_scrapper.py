import requests
from bs4 import BeautifulSoup
import time
import random
from fake_useragent import UserAgent
import re
import json

class SmartPriceScraper:
    def __init__(self):
        self.ua = UserAgent()
        self.session = requests.Session()
        self.product_database = self.load_product_database()
        
    def load_product_database(self):
        """Load a database of realistic product data for different categories"""
        return {
            'iphone': [
                {'name': 'iPhone 15 Pro Max 256GB', 'base_price': 134900, 'category': 'premium'},
                {'name': 'iPhone 15 Pro 128GB', 'base_price': 119900, 'category': 'premium'},
                {'name': 'iPhone 15 128GB', 'base_price': 66900, 'category': 'flagship'},
                {'name': 'iPhone 14 128GB', 'base_price': 52900, 'category': 'flagship'},
                {'name': 'iPhone 13 128GB', 'base_price': 44900, 'category': 'midrange'},
                {'name': 'iPhone SE 64GB', 'base_price': 34900, 'category': 'budget'}
            ],
            'samsung': [
                {'name': 'Samsung Galaxy S24 Ultra 512GB', 'base_price': 129999, 'category': 'premium'},
                {'name': 'Samsung Galaxy S24+ 256GB', 'base_price': 99999, 'category': 'premium'},
                {'name': 'Samsung Galaxy S24 128GB', 'base_price': 79999, 'category': 'flagship'},
                {'name': 'Samsung Galaxy A54 5G', 'base_price': 34999, 'category': 'midrange'},
                {'name': 'Samsung Galaxy M34 5G', 'base_price': 16999, 'category': 'budget'},
                {'name': 'Samsung Galaxy F14 5G', 'base_price': 12999, 'category': 'budget'}
            ],
            'laptop': [
                {'name': 'MacBook Pro 16-inch M3 Pro', 'base_price': 249900, 'category': 'premium'},
                {'name': 'MacBook Air 13-inch M2', 'base_price': 114900, 'category': 'premium'},
                {'name': 'Dell XPS 13 Plus', 'base_price': 149990, 'category': 'flagship'},
                {'name': 'HP Pavilion 15', 'base_price': 54990, 'category': 'midrange'},
                {'name': 'Lenovo IdeaPad 3', 'base_price': 34990, 'category': 'budget'},
                {'name': 'Acer Aspire 5', 'base_price': 42990, 'category': 'budget'}
            ],
            'headphones': [
                {'name': 'Sony WH-1000XM5 Wireless', 'base_price': 29990, 'category': 'premium'},
                {'name': 'Apple AirPods Pro 2', 'base_price': 24900, 'category': 'premium'},
                {'name': 'Bose QuietComfort 45', 'base_price': 28900, 'category': 'premium'},
                {'name': 'JBL Tune 760NC', 'base_price': 5999, 'category': 'midrange'},
                {'name': 'Boat Rockerz 450', 'base_price': 1999, 'category': 'budget'},
                {'name': 'Realme Buds Wireless 3', 'base_price': 1799, 'category': 'budget'}
            ],
            'watch': [
                {'name': 'Apple Watch Series 9 GPS', 'base_price': 41900, 'category': 'premium'},
                {'name': 'Samsung Galaxy Watch 6', 'base_price': 29999, 'category': 'premium'},
                {'name': 'Fitbit Versa 4', 'base_price': 22999, 'category': 'midrange'},
                {'name': 'Amazfit GTS 4', 'base_price': 12999, 'category': 'budget'},
                {'name': 'Noise ColorFit Pro 4', 'base_price': 3999, 'category': 'budget'}
            ],
            'shoes': [
                {'name': 'Nike Air Jordan 1 Retro', 'base_price': 13995, 'category': 'premium'},
                {'name': 'Adidas Ultraboost 22', 'base_price': 17999, 'category': 'premium'},
                {'name': 'Puma RS-X Toys', 'base_price': 8999, 'category': 'midrange'},
                {'name': 'Reebok Royal Glide', 'base_price': 4999, 'category': 'budget'},
                {'name': 'Sparx SX0457', 'base_price': 1299, 'category': 'budget'}
            ]
        }
    
    def detect_category(self, query):
        """Detect the product category from search query"""
        query_lower = query.lower()
        
        if any(word in query_lower for word in ['iphone', 'apple phone']):
            return 'iphone'
        elif any(word in query_lower for word in ['samsung', 'galaxy']):
            return 'samsung'
        elif any(word in query_lower for word in ['laptop', 'macbook', 'notebook']):
            return 'laptop'
        elif any(word in query_lower for word in ['headphone', 'earphone', 'airpods', 'earbud']):
            return 'headphones'
        elif any(word in query_lower for word in ['watch', 'smartwatch']):
            return 'watch'
        elif any(word in query_lower for word in ['shoe', 'sneaker', 'nike', 'adidas']):
            return 'shoes'
        else:
            return 'generic'
    
    def generate_realistic_products(self, query, count=20):
        """Generate realistic, varied products based on query"""
        category = self.detect_category(query)
        products = []
        
        platforms = ['Amazon', 'Flipkart', 'Myntra', 'Snapdeal', 'eBay', 'Tata CLiQ', 'Reliance Digital']
        
        # Get base products for the category
        base_products = self.product_database.get(category, [])
        
        if not base_products:
            # Generic products for unknown categories
            base_products = [
                {'name': f'{query} Premium Edition', 'base_price': random.randint(20000, 100000), 'category': 'premium'},
                {'name': f'{query} Latest Model', 'base_price': random.randint(10000, 50000), 'category': 'flagship'},
                {'name': f'{query} Standard Version', 'base_price': random.randint(5000, 20000), 'category': 'midrange'},
                {'name': f'{query} Basic Model', 'base_price': random.randint(1000, 8000), 'category': 'budget'}
            ]
        
        # Generate variations
        for i in range(count):
            base_product = random.choice(base_products)
            platform = random.choice(platforms)
            
            # Create price variations based on platform and category
            price_variation = random.uniform(0.8, 1.2)  # ±20% variation
            final_price = base_product['base_price'] * price_variation
            
            # Some platforms have discounts
            original_price = None
            if random.random() > 0.4:  # 60% chance of having original price
                discount = random.uniform(0.05, 0.3)  # 5-30% discount
                original_price = final_price / (1 - discount)
            
            # Rating based on category and price
            base_rating = 4.0
            if base_product['category'] == 'premium':
                base_rating += random.uniform(0.3, 0.7)
            elif base_product['category'] == 'budget':
                base_rating -= random.uniform(0.2, 0.5)
            
            rating = round(base_rating + random.uniform(-0.2, 0.2), 1)
            rating = max(3.0, min(5.0, rating))  # Keep between 3-5
            
            # Review count based on popularity
            review_count = int(base_product['base_price'] * random.uniform(0.1, 2))
            review_count = max(10, min(50000, review_count))
            
            # Platform-specific variations
            if platform == 'Amazon':
                rating += random.uniform(0, 0.2)
            elif platform == 'Flipkart':
                # Flipkart often has better deals
                if original_price:
                    original_price *= random.uniform(1.05, 1.15)
            
            products.append({
                'name': f"{base_product['name']} ({platform})",
                'price': round(final_price, 2),
                'original_price': round(original_price, 2) if original_price else None,
                'rating': rating,
                'review_count': review_count,
                'url': f'https://www.{platform.lower().replace(" ", "")}.com/search?q={query.replace(" ", "+")}',
                'image_url': f'https://via.placeholder.com/150?text={query[:10]}',
                'platform': platform
            })
        
        # Sort by price and remove exact duplicates
        unique_products = []
        seen_prices = set()
        
        for product in products:
            price_key = f"{product['price']}_{product['platform']}"
            if price_key not in seen_prices:
                seen_prices.add(price_key)
                unique_products.append(product)
        
        unique_products.sort(key=lambda x: x['price'])
        return unique_products[:count]
    
    def try_real_scraping(self, query):
        """Try to get real data with better error handling"""
        try:
            # Simple API-based approach (using free APIs)
            products = self.try_free_apis(query)
            if products:
                return products, "api"
            
            # Fallback to enhanced mock data
            return self.generate_realistic_products(query, 20), "smart_mock"
            
        except Exception as e:
            print(f"❌ Real scraping failed: {e}")
            return self.generate_realistic_products(query, 20), "smart_mock"
    
    def try_free_apis(self, query):
        """Try free product APIs"""
        try:
            # Using a simple approach with product API simulation
            # In a real scenario, you'd use actual APIs like:
            # - Amazon Product Advertising API
            # - Flipkart Affiliate API
            # - RapidAPI product APIs
            
            # For now, we'll simulate API response with realistic data
            return None  # Fall back to smart mock data
            
        except Exception as e:
            return None
    
    def search_products(self, query):
        """Main search function that returns varied, realistic products"""
        print(f"🔍 Smart search for: '{query}'")
        
        # Try real scraping first
        products, source = self.try_real_scraping(query)
        
        # Ensure we have enough products
        if len(products) < 15:
            additional_products = self.generate_realistic_products(query, 15 - len(products))
            products.extend(additional_products)
        
        # Remove duplicates and sort
        unique_products = []
        seen_combinations = set()
        
        for product in products:
            combo = f"{product['name']}_{product['price']}_{product['platform']}"
            if combo not in seen_combinations:
                seen_combinations.add(combo)
                unique_products.append(product)
        
        unique_products.sort(key=lambda x: x['price'])
        final_products = unique_products[:20]  # Max 20 products
        
        print(f"✅ Generated {len(final_products)} unique products (source: {source})")
        
        # Show sample of products
        print("📊 Sample products:")
        for i, product in enumerate(final_products[:3], 1):
            discount = ""
            if product['original_price']:
                discount_pct = ((product['original_price'] - product['price']) / product['original_price']) * 100
                discount = f" ({discount_pct:.0f}% OFF)"
            print(f"   {i}. {product['platform']}: ₹{product['price']}{discount}")
        
        return final_products, source

# Test the smart scraper
if __name__ == "__main__":
    scraper = SmartPriceScraper()
    
    test_queries = ['iphone 15', 'samsung galaxy', 'laptop', 'headphones', 'nike shoes']
    
    for query in test_queries:
        print(f"\n{'='*50}")
        print(f"Testing: {query}")
        print('='*50)
        
        products, source = scraper.search_products(query)
        
        platform_count = {}
        for product in products:
            platform = product['platform']
            platform_count[platform] = platform_count.get(platform, 0) + 1
        
        print(f"\nPlatform distribution:")
        for platform, count in sorted(platform_count.items()):
            print(f"  {platform}: {count} products")
        
        price_range = f"₹{products[0]['price']} - ₹{products[-1]['price']}"
        print(f"Price range: {price_range}")